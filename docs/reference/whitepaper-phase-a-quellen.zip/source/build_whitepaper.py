"""Phase-A architecture whitepaper. Vector figures, embedded fonts, explicit pages.
Build: python source/build_whitepaper.py
Dependencies: reportlab, pypdf. Fonts: Calibri, Segoe UI, Consolas (Windows or locally available TTF files).
Sources and measurement method are documented in the paper and evidence.json.
"""
from pathlib import Path
from math import atan2, cos, sin
from xml.sax.saxutils import escape
import re, json, hashlib, argparse
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,help='Destination PDF; default: output/pdf/architektur-whitepaper-phase-a.pdf')
parser.add_argument('--font-dir',type=Path,help='Directory containing Calibri, Segoe UI and Consolas TTF files')
args=parser.parse_args()
PDF=args.output or ROOT/'output'/'pdf'/'architektur-whitepaper-phase-a.pdf'
fonts=[('Body','calibri.ttf'),('Bold','calibrib.ttf'),('Italic','calibrii.ttf'),('Display','segoeuib.ttf'),('Light','segoeuil.ttf'),('Mono','consola.ttf')]
candidates=[args.font_dir] if args.font_dir else [Path('C:/Windows/Fonts'),Path('/mnt/c/Windows/Fonts')]
font_dir=next((d for d in candidates if all((d/f).is_file() for _,f in fonts)),None)
if font_dir is None:
    parser.error('Required font files not found; supply --font-dir. No font files are redistributed.')
PDF.parent.mkdir(parents=True,exist_ok=True)
TMP=ROOT/'tmp'/'pdfs'; TMP.mkdir(parents=True,exist_ok=True)
for n,f in fonts:
    pdfmetrics.registerFont(TTFont(n,str(font_dir/f)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Italic',boldItalic='Bold')
W,H=A4; M=44; CW=W-2*M
INK='#152F3D'; NAVY='#102936'; TEAL='#007D79'; MINT='#6DD8C1'
BLUE='#3E6F9D'; PURPLE='#7D6495'; AMBER='#AA682C'; PAPER='#F8F7F3'
WHITE='#FFFFFF'; MUTED='#576B75'; LINE='#CAD5D7'; PALE='#EAF0EF'
PB='#EDF2F7'; PP='#F1EDF5'; PA='#F5EDE3'
c=canvas.Canvas(str(PDF),pagesize=A4,pageCompression=1)
c.setTitle('Stochastische Agenten, deterministische Kontrolle - Architektur-Whitepaper, Phase A')
c.setAuthor('Dieter Esser | Dual-Agent-Orchestrator')
c.setSubject('Rollenverträge, Providergrenzen, Records und Betriebsnachweise. Stand 28.09.2026.')
TEXT=[]; BOXES=[]

def rect(x,y,w,h,color,edge=None,r=0):
    c.setFillColor(HexColor(color));c.setLineWidth(.7)
    if edge:c.setStrokeColor(HexColor(edge))
    if r:c.roundRect(x,H-y-h,w,h,r,fill=1,stroke=bool(edge))
    else:c.rect(x,H-y-h,w,h,fill=1,stroke=bool(edge))
def line(x,y,xx,yy,color=LINE,width=.7,dash=None):
    c.setStrokeColor(HexColor(color));c.setLineWidth(width);c.setDash(dash or [])
    c.line(x,H-y,xx,H-yy);c.setDash([])
def txt(s,x,y,size=10,font='Body',color=INK,align='left'):
    c.setFillColor(HexColor(color));c.setFont(font,size)
    if align=='center':c.drawCentredString(x,H-y-size*.82,s)
    elif align=='right':c.drawRightString(x,H-y-size*.82,s)
    else:c.drawString(x,H-y-size*.82,s)
    w=pdfmetrics.stringWidth(s,font,size)
    if align=='left' and (x<0 or x+w>W+.1):raise ValueError('Text too wide: '+s)
def para(s,x,y,w,size=10.6,leading=14.4,color=INK,font='Body',maxh=None,record=True):
    p=Paragraph(s,ParagraphStyle('p',fontName=font,fontSize=size,leading=leading,textColor=HexColor(color),allowWidows=0,allowOrphans=0))
    _,h=p.wrap(w,H)
    if maxh is not None and h>maxh+.1:raise ValueError(f'Page {c.getPageNumber()}: {h}>{maxh}: '+s[:70])
    if y+h>H-65:raise ValueError(f'Page {c.getPageNumber()} text too low ({y+h}): '+s[:70])
    p.drawOn(c,x,H-y-h)
    BOXES.append({'page':c.getPageNumber(),'x':x,'y':y,'w':w,'h':h,'text':s})
    if record:TEXT.append(re.sub('<[^>]+>','',s).replace('&amp;','&').replace('&lt;','<').replace('&gt;','>'))
    return y+h
def body(s,y,w=CW,x=M,size=10.6):return para(s,x,y,w,size,size*1.36)+11
def label(s,x,y,color=TEAL,size=8):txt(s,x,y,size,'Bold',color)
def sub(s,y,x=M):txt(s,x,y,13,'Display',INK);TEXT.append('\n### '+s);return y+24
def arrow(x,y,xx,yy,color=TEAL,dashed=False):
    line(x,y,xx,yy,color,1.05,[3,3] if dashed else None)
    a=atan2(yy-y,xx-x)
    line(xx-6*cos(a-.45),yy-6*sin(a-.45),xx,yy,color,1.05)
    line(xx-6*cos(a+.45),yy-6*sin(a+.45),xx,yy,color,1.05)
def dot(x,y,r=3,color=TEAL):
    c.setFillColor(HexColor(color));c.circle(x,H-y,r,fill=1,stroke=0)
def box(x,y,w,h,title,detail='',color=TEAL,bg=PALE):
    rect(x,y,w,h,bg,LINE,5);rect(x,y,3,h,color)
    txt(title,x+12,y+11,10.2,'Bold',color)
    if detail:para(detail,x+12,y+30,w-24,9.2,12.2,maxh=h-34)
def callout(title,s,y,h=84,color=TEAL,bg=PALE):
    rect(M,y,CW,h,bg,r=5);rect(M,y,3,h,color)
    label(title.upper(),M+14,y+12,color)
    para(s,M+14,y+30,CW-28,10.2,14,maxh=h-38)
def caption(n,s,y):
    label(f'ABB. {n:02d}',M,y)
    para(s,M+48,y-1,CW-48,8.8,11.6,MUTED,maxh=38)
def footer(n,dark=False):
    fg='#B0C4CB' if dark else MUTED
    line(M,790,W-M,790,'#3A5563' if dark else LINE)
    txt('DUAL-AGENT-ORCHESTRATOR',M,803,7.1,'Bold',fg)
    txt('PHASE A  /  28.09.2026',W/2,803,7.1,'Body',fg,'center')
    txt(f'{n:02d} / 14',W-M,802,8,'Mono',fg,'right')
def header(n,section,title,deck):
    rect(0,0,W,H,PAPER);label('ARCHITEKTUR / WHITEPAPER',M,29,MUTED)
    label('PHASE A · V1.3',W-M-77,29,TEAL)
    line(M,56,W-M,56);txt(f'{n-1:02d}',M,77,32,'Light',TEAL)
    label(section.upper(),M+55,84)
    txt(title,M,122,26,'Display')
    para(deck,M,168,CW,11.3,15.3,MUTED,maxh=47,record=False)
    TEXT.append('\n## '+title+'\n\n'+deck)
    c.bookmarkPage('page'+str(n));c.addOutlineEntry(title,'page'+str(n),level=0)
    footer(n)
def end():c.showPage()
def table(headers,rows,widths,y,rowh=39):
    x=M;rect(M,y,CW,29,NAVY)
    for h,w in zip(headers,widths):txt(h,x+9,y+10,8.7,'Bold',WHITE);x+=w
    yy=y+29
    for i,row in enumerate(rows):
        rect(M,yy,CW,rowh,WHITE if i%2==0 else PALE)
        x=M
        for cell,w in zip(row,widths):para(cell,x+9,yy+9,w-18,9.4,12.2,maxh=rowh-14);x+=w
        yy+=rowh
    line(M,yy,W-M,yy)
    return yy

# 1. Cover
rect(0,0,W,H,NAVY)
label('DUAL-AGENT-ORCHESTRATOR',M,35,MINT,9)
label('ARCHITEKTUR / PHASE A',W-M-132,35,MINT,8)
line(M,66,W-M,66,'#3A5563')
label('ROLLEN, VERTRÄGE UND BETRIEBSNACHWEISE',M,99,'#B4CACF',9)
txt('Stochastische',M,133,41,'Display',WHITE)
txt('Agenten,',M,183,41,'Display',WHITE)
txt('deterministische',M,251,36.5,'Light',MINT)
txt('Kontrolle.',M,297,41,'Display',MINT)
para('Wie getrennte Rollen, gebundene Nachweise und eine prüfbare Historie agentische Entwicklungsarbeit kontrollierbar machen.',M,365,455,14,19,'#D7E4E6',maxh=63)
for x,w,t in [(M,123,'Agentenvorschläge'),(M+157,166,'Deterministische Gates'),(M+356,151,'Prüfbare Records')]:
    rect(x,464,w,51,'#24404C',r=5);txt(t,x+w/2,483,9.7,'Bold',MINT,'center')
arrow(M+125,490,M+150,490,MINT);arrow(M+325,490,M+350,490,MINT)
rect(0,572,W,189,PAPER)
label('DOKUMENTIERTER STAND',M,593)
para('Phase A: Der Rollenvertrag ist vom Provider entkoppelt. Die aktuelle Besetzung ist praktisch erprobt; weitere Kombinationen haben einen definierten Qualifikationspfad.',M,617,CW,14,19,maxh=62)
txt('Dieter Esser',M,704,11,'Bold')
txt('Technisches Whitepaper · Ausgabe 1.3 · 28. September 2026',M,725,9.5,'Body',MUTED)
footer(1,True);end()

# 2. Abstract and scope
header(2,'Zusammenfassung','Was Phase A erreicht','Ein Architekturbericht über einen real betriebenen Entwicklungsorchestrator und die Grenzen seines heutigen Nachweises.')
y=body('Der Dual-Agent-Orchestrator organisiert Softwareänderungen als kontrollierten Prozess: Ein Implementer plant und ändert Code, ein davon getrennter Reviewer beurteilt Plan und Umsetzung. Der Orchestrator führt die deterministische Validierung aus, bindet ihre Ergebnisse an den geprüften Stand und entscheidet anhand expliziter Regeln, ob der Prozess fortgesetzt werden darf. Sprachmodelle liefern Vorschläge und Urteile; die Autorität über Zustandsübergänge bleibt im Programm. [1]',231)
y=body('Phase A beseitigt die frühere Gleichsetzung von Rolle und Anbieter. <b>Implementer</b> und <b>Reviewer</b> sind jetzt fachliche Rollen; Provider, Modell, Aufwand und Laufzeitgrenze gehören zu gebundenen Profilen. Drei konfigurierbare Slots bilden Planung/Implementierung, laufendes Review und abschließendes Branchreview ab. Der dritte Slot ist eine gesonderte Reviewer-Aufgabe, keine dritte fachliche Rolle. [1, 2]',y)
callout('Die zentrale Aussage','Die Architektur erlaubt, weitere Provider systematisch anzuschließen. Heute zugelassen und erprobt ist Codex / Claude / Claude. Eine neutrale Schnittstelle allein erteilt noch keiner anderen Kombination eine Freigabe.',y+4,88)
y+=110
y=body('Diese Ausgabe dokumentiert den abgenommenen Stand der Phase A vom 28. September 2026. Der unterstützte Betriebsrahmen ist Linux beziehungsweise WSL 2; die Fallstudie wurde unter WSL 2 / Ubuntu durchgeführt. [1, 3]',y)
y=body('Das Papier verbindet Implementierung und Konfiguration, gespeicherte Tests und Laufrecords sowie Erfahrungen aus Entwicklungs- und Anwendungseinsätzen. Die dokumentierte Abnahme macht den Ablauf an einer realen Aufgabe nachvollziehbar. Weitergehende Aussagen zur Zuverlässigkeit erfordern eine breitere Messreihe mit unterschiedlichen Aufgaben und Fehlersituationen.',y)
line(M,685,W-M,685)
label('LESEWEG',M,701)
para('Prinzip und Architektur  S. 3-5  ·  Provider und JSON  S. 6-7<br/>Records und Recovery  S. 8-9  ·  Praxis und Messwerte  S. 10-11<br/>Abo-Betrieb  S. 12  ·  Einordnung und Quellen  S. 13-14',M,721,CW,9.8,14,MUTED,maxh=45)
end()

# 3. Motivation and control boundary
header(3,'Entwurfsprinzip','Warum Schranken nötig sind','Die Variabilität eines Modells ist nützlich beim Entwerfen. Als alleinige Grundlage für einen Workflowzustand ist sie zu schwach.')
y=body('Ein LLM kann eine gute Lösung finden und trotzdem ein Feld auslassen, einen offenen Befund falsch referenzieren oder eine gelungene Änderung zu früh als fertig melden. Auch zwei plausible Antworten können sich widersprechen. Die Kontrolllogik muss deshalb auf prüfbaren Bedingungen beruhen: Wer antwortet auf welchen Auftrag, für welchen Codezustand und mit welcher Befugnis?',231)
y=body('Die Entwicklung begann mit Kommunikation über Markdown-Dateien. Deren Ausgabeform erwies sich als zu unstet für verlässliche automatische Auswertung. Die JSON-Schicht war damit keine kosmetische Verbesserung. Sie schuf die Voraussetzung, strukturierte Entscheidungen, eindeutige Bindungen und negative Antworten maschinell auszuwerten. Markdown bleibt als lesbare Dokumentation und Auditansicht sinnvoll. [1, 8]',y)
box(M,403,151,86,'1 · Form','Native JSON-Ausgabe entspricht dem Writer-Schema.',BLUE,PB)
box(M+178,403,151,86,'2 · Bedeutung','Request, Rolle und erlaubte Befunde passen.',PURPLE,PP)
box(M+356,403,151,86,'3 · Übergang','Validierung und Workflowregeln erlauben den Schritt.')
arrow(M+153,447,M+173,447);arrow(M+331,447,M+351,447)
caption(1,'Drei getrennte Prüfungen. Syntaktisch korrektes JSON ist erst der Anfang; es ist noch keine fachlich zulässige Entscheidung.',503)
y=body('Im heutigen Vertrag werden fehlende oder ungültige native Antworten zurückgewiesen. Es gibt keinen Freitextparser als Ersatz und keine stillschweigende Reparatur zu einer Freigabe. Ein begrenzter neuer Provideraufruf kann einen Fehler behandeln; dessen Antwort muss wiederum den unveränderten Vertrag erfüllen. Die Abnahme zeigt genau diese Grenze an einer unzulässigen Finding-Referenz. [1, 3]',553)
y=body('<b>Deterministisch</b> meint hier die Anwendung der Kontrollregeln auf gebundene Daten. Es meint nicht, dass Modellantworten, Tests oder die Außenwelt stets identisch ausfallen. Ein grüner Testlauf belegt die ausgeführten Prüfungen am gemessenen Stand. Seine Aussagekraft bleibt von der Testauswahl und deren Qualität abhängig.',y)
y=sub('Fehler früh abfangen',y+5)
body('Begrenzte Slices, explizite Befunde und geprüfte Zwischenstände verkürzen die Rückkopplung. Abweichungen können dadurch früher erkannt und korrigiert werden, bevor weitere Änderungen auf ihnen aufbauen. Das senkt das Risiko schleichender Fehlerfortschreibung; die Aussagekraft bleibt von den Prüfungen abhängig. [1]',y)
end()

# 4. Components
header(4,'Architektur','Eine kleine Autoritätsgrenze','Vereinfachtes UML-Komponentendiagramm: Vorschläge entstehen bei den Agenten, verbindliche Prozessfakten im Orchestrator.')
box(M,231,220,76,'«component» Implementer','Planen · erlaubten Code ändern<br/>Native Ergebnisantwort',BLUE,PB)
box(M+286,231,221,76,'«component» Reviewer','Plan / Slice / Gesamtdiff prüfen<br/>Befunde und Urteil',PURPLE,PP)
arrow(M+123,309,M+206,368,BLUE);arrow(M+226,368,M+146,309,BLUE,dashed=True)
arrow(M+384,309,M+302,368,PURPLE);arrow(M+282,368,M+361,309,PURPLE,dashed=True)
txt('Antwort / Request',M+7,337,8,'Body',BLUE)
txt('Request / Urteil',W-M-7,337,8,'Body',PURPLE,'right')
box(M+126,376,255,83,'«component» Orchestrator','Rollenvertrag · Domainprüfung · Workflow<br/>Gebundener Operatorauftrag und Policy')
arrow(M+200,461,M+112,502);arrow(M+309,461,M+395,502)
label('führt aus',M+103,474,TEAL,7.5);label('schreibt',M+378,474,TEAL,7.5)
box(M,508,220,71,'«component» Validierung','Befehle ausführen; Evidenz erzeugen<br/>Attestierung an Fingerprint binden')
box(M+286,508,221,71,'«artifact» Record-Store','Append-only Fakten und Referenzen<br/>Daraus: State, Checkpoints und Audit')
caption(2,'Logische Zuständigkeiten, keine Darstellung einzelner Prozesse. Record-Schreibvorgänge und attestierte Validierung werden vom Orchestrator ausgeführt.',585)
y=body('Der Implementer besitzt kein Recht zur eigenen Freigabe und schließt keine reviewer-eigenen Findings. Der Reviewer soll ausschließlich lesend arbeiten. Phase A verwendet dafür einen separaten Snapshot, entfernte Schreibbits und begrenzte CLI-Werkzeuge. Das sind konkrete Schutzmechanismen; daraus folgt noch kein universeller Nachweis einer unüberwindbaren Betriebssystemgrenze. Die breitere Isolationsprüfung steht ausdrücklich im nächsten Qualifikationspaket. [1, 2, 4]',630)
body('Git-Transaktionen und Queue-Bewegungen gehören zur Steuerung, nicht zu den Agentenantworten. Ein optionaler lokaler Abschlussmerge ist eine gebundene Workflowpolicy; im dokumentierten Abnahmelauf war er deaktiviert. Der Merge erfolgte nach dem abgeschlossenen Lauf. [1, 3]',y)
end()

# 5. Sequence
header(5,'Gewaltenteilung','Review ist ein eigener Prozess','Das Vier-Augen-Prinzip als technischer Rollenvertrag. Vereinfachtes UML-Sequenzdiagramm für Planung und Prüfung eines Slices.')
xs=[97,254,422];names=['Implementer','Orchestrator','Reviewer'];cols=[BLUE,TEAL,PURPLE]
for x,n,col in zip(xs,names,cols):
    rect(x-52,229,104,31,PB if col==BLUE else PP if col==PURPLE else PALE,LINE,3)
    txt(n,x,240,10,'Bold',col,'center');line(x,260,x,507,LINE,1,[3,3])
def msg(a,b,y,s,col=TEAL):
    arrow(xs[a],y,xs[b],y,col);txt(s,(xs[a]+xs[b])/2,y-15,8.3,'Body',col,'center')
msg(0,1,281,'Plan als native Antwort',BLUE);msg(1,2,310,'Gebundener Planreview')
msg(2,1,339,'Plan freigegeben',PURPLE)
msg(1,0,368,'Slice ausführen');msg(0,1,397,'Änderung + Dispositionen',BLUE)
rect(215,411,195,25,PALE,LINE,3);txt('Validierung am Fingerprint',312,419,8.7,'Bold',TEAL,'center')
msg(1,2,457,'Diff + Attestierung');msg(2,1,490,'Urteil + Finding-Übergänge',PURPLE)
caption(3,'Bei Ablehnung folgt eine Korrektur mit erneuter Prüfung. Erst nach erfüllten Commitregeln schreibt der Orchestrator den Slice-Commit.',519)
y=body('Freigaberelevant sind die vom Orchestrator selbst ausgeführten Prüfungen und ihre an den Änderungsstand gebundenen Ergebnisse. Selbstauskünfte des Implementers ersetzen diesen Nachweis nicht. Auch Teständerungen müssen im Review fachlich geprüft werden. [1]',566)
y=body('Ein Finding bleibt an seinen ursprünglichen Slice und seinen meldenden Reviewer gebunden. Der Implementer muss jeden offenen Befund begründet behandeln: akzeptieren und korrigieren oder einen gewöhnlichen Befund begründet zurückweisen. Die Schließung bleibt beim Reviewer. Ein Blocker ist nicht durch eine Ablehnung des Implementers erledigt. [1]',y)
y=body('Die erste Prüfung dient der Entdeckung; weitere abgelehnte Runden müssen Fortschritt zeigen. Grenzen für Runden und Abschlussreviews verhindern endlose Schleifen. Nach allen Slices untersucht der Finalreviewer den vollständigen Branch-Diff. Neue Befunde führen in einen gewöhnlichen Folgeauftrag; das Abschlussreview selbst ist keine Korrekturschleife. [1]',y)
end()

# 6. Provider support
header(6,'Provider und Rollen','Heute unterstützt, morgen geprüft','Der neutralisierte Vertrag ist die Voraussetzung für Austauschbarkeit. Die konkrete Zulassung bleibt eine eigene Entscheidung.')
table(['Provider / CLI','Implementer','Reviewer','Finalreviewer'],[
 ['OpenAI Codex','Phase A','Phase C geplant','Phase C geplant'],
 ['Anthropic Claude Code','Phase C geplant','Phase A','Phase A'],
 ['Google Antigravity CLI','Phase C geplant','Phase B geplant','Phase B geplant'],
],[158,108,118,123],231,44)
para('Phase A ist heute zugelassen; B/C sind geplant. „certified“ bezeichnet eine projektinterne Freigabe. [2, 4]<br/><b>Antigravity CLI (agy)</b> ist Googles terminalbasiertes Werkzeug für agentische Softwareentwicklung. [14]',M,405,CW,9.7,13.2,MUTED,maxh=62)
y=sub('Was im Lauf gebunden wird',473)
y=body('Die TOML-Konfiguration ordnet jedem Slot ein Profil zu. Vor dem Start werden unter anderem Provider, Hersteller, Modellanforderung, Effort, Timeout, Binary-Identität sowie Capability-, Transport-, Rechte-, Policy- und Zulassungsdigest festgehalten. Resume prüft diese Bindungen erneut. Der Abnahmelauf verwendete Codex CLI 0.156.1 mit gpt-6-sol/high und Claude Code 2.1.283 mit opus/high. Modellnamen sind angeforderte Profilwerte, kein unabhängiger Nachweis der internen Modellausführung. [2, 3]',y)
y=sub('Die Grenze der freien Besetzung',y+2)
y=body('Implementer und beide Reviewer-Slots müssen verschiedenen Herstellern zugeordnet sein. Beide Review-Slots dürfen denselben Hersteller nutzen. Nach entsprechender Qualifikation wäre etwa Claude / Codex / Codex möglich; Claude / Codex / Claude bliebe unzulässig. Andere Aliasnamen, Modelle oder Binarypfade ändern die Herstelleridentität nicht. [2, 4]',y)
callout('Der nächste Schritt','Phase B soll Antigravity zunächst experimentell als Reviewer zulassen. Phase C erweitert die Rollenbesetzung je geprüfter Kombination und verlangt einen realen Funktionsnachweis der neuen Topologie.',y+3,77)
end()

# 7. Contracts and lessons
header(7,'Strukturierte Kommunikation','Gleiches JSON ist nicht genug','Die OpenSQL-Analogie hilft: Ein einheitlicher fachlicher Vertrag braucht Übersetzungen für unterschiedliche Providergrenzen.')
y=body('JSON normiert eine Syntax. Es normiert weder die vom Anbieter akzeptierte Teilmenge von JSON Schema noch dessen Regex-Dialekt, Transporthülle, Größenlimits oder Werkzeugrechte. Zwei CLIs können beide strukturierte Ausgabe anbieten und denselben Writer trotzdem unterschiedlich behandeln. Ein universelles Promptformat löst diese Unterschiede nicht.',231)
box(M,342,151,87,'Rollenvertrag','Was die Antwort fachlich bedeuten muss.',TEAL,PALE)
box(M+178,342,151,87,'Writer-Projektion','Was der jeweilige Provider erzwingen kann.',BLUE,PB)
box(M+356,342,151,87,'Lokale Prüfung','Schema, Requestbindung und Domainvertrag.',PURPLE,PP)
arrow(M+153,385,M+173,385);arrow(M+331,385,M+351,385)
caption(4,'Ein Vertrag, unterschiedliche Projektionen. Eine entfernte Writer-Einschränkung braucht eine begründete lokale Gegenprüfung.',443)
y=sub('Erfahrungen aus dem Umbau',498)
y=body('In Phase A wurden fachliche Rollen und v3-Nachrichten von Providernamen getrennt. Eine eingeschränkte Pattern-Grammatik und providerabhängige Writer-Projektionen machen Unterschiede explizit. Ein Review des Umbaus fand zunächst optionale Bindungsfelder, bei denen Resume Vergleiche überspringen konnte. Sie wurden verpflichtend; auch die aufgelöste Binary-Identität wird gebunden. [1, 5]',y)
y=body('Der vorgelagerte Antigravity-PoC zeigt, warum Live-Proben nötig sind: Eine Kombination aus <font name="Mono">prefixItems</font> und <font name="Mono">items: false</font> wurde abgewiesen. Bei einem anderen Versuch gab es trotz Exitcode 0 keine verwertbare strukturierte Antwort. Ein positiver Einzelfall unter angepasstem Schema war deshalb noch keine Adapterfreigabe. Transporterfolg, Formvertrag, Domainvertrag und Rollenfähigkeit sind getrennte Nachweise. [4, 5]',y)
callout('Portabilität als überprüfbare Eigenschaft','Neue Kombinationen brauchen Prüfungen für Vertrag, Transport, Rechte, Fehlerwege und die konkrete Rolle. Ein Schema-PoC ersetzt weder Isolation noch einen vollständigen Orchestratorlauf.',y+1,78,color=AMBER,bg=PA)
end()

# 8. Records
header(8,'Persistenz und Bindungen','Records tragen die Autorität','Der Protokollmodus heißt weiterhin „structured-v2“. Artefakt-Records und neutrale Provider-Nachrichten verwenden v3-Schemas. Protokollmodus, Schema und Reducer sind getrennte Versionsebenen.')
y=body('Validierte append-only Records gemäß <font name="Mono">orchestrator-artifact-v3</font> (<font name="Mono">schema_version: "3"</font>) bilden die technische Quelle der repräsentierten Fakten. RunIdentity und RunProfile binden Auftrag, Branchbasis, Modus und Rollenprofile. SliceBoundary hält den unveränderlichen Start eines Slices fest. Ergebnisse, Befunde, Validierung und Übergänge verweisen auf ihren Kontext. Der installierte Reducer rekonstruiert daraus den Betriebszustand. [1]',231)
for x,t,d in [(M,'Run / Profil','Identität + Policy'),(M+175,'Slice / Review','Start + Evidenz'),(M+350,'Übergang','Befugnis + Ergebnis')]:
    box(x,349,157,70,t,d)
arrow(M+159,384,M+169,384);arrow(M+334,384,M+344,384)
txt('Hash- und Vorgängerbindungen, hier als lineares Schema vereinfacht',W/2,435,9,'Body',MUTED,'center')
caption(5,'Die Grafik erklärt Abhängigkeiten; sie bildet nicht jedes Recordformat oder jede Vorgängerrelation ab.',460)
y=sub('Was Hashes leisten',511)
y=body('Der Repository-Fingerprint bindet die Prüfung an einen konkreten Stand. Outputdigests binden gespeicherte Evidenz; Inhalts- und Vorgängerbindungen machen Inkonsistenzen innerhalb der prüfbaren Historie erkennbar. Hashes beweisen jedoch weder die Wahrheit eines Reviewerurteils noch schützen sie allein gegen einen Angreifer, der alle Records und Referenzen neu schreiben kann. Dafür wäre eine zusätzliche Vertrauensgrenze nötig.',y)
y=sub('Caches sind entbehrlich, Fakten nicht',y+2)
y=body('<font name="Mono">state.json</font>, Checkpoints und <font name="Mono">head.json</font> sind abgeleitete Hilfen. Ein fehlender oder unpassender Cache kann aus einer gültigen Kette neu entstehen. Eine beschädigte oder inkompatible Kette darf dagegen nicht durch geratenen Zustand oder Markdown-Einträge repariert werden. Ältere Protokolle und fremde Reducersemantik werden abgewiesen. Append-only ist dabei eine durchgesetzte Softwarekonvention auf Dateien, kein unveränderliches Speichermedium. [1]',y)
end()

# 9. Recovery
header(9,'Recovery','Weiter nur bei klarem Zustand','Ein Neustart darf Wiederholung ermöglichen. Er darf eine unbekannte Außenwirkung nicht als erfolgreich oder folgenlos erfinden.')
y=body('Git-Commit, Providerstart, autoritatives Schreiben und Queue-Bewegung werden durch stabile Intent-/Result-Paare erfasst. Bei offenem Intent darf Resume die betreffende Außenwirkung gezielt abgleichen. Ist sie nachweislich erfolgt, wird das Ergebnis nachvollzogen; ist sie nachweislich nicht erfolgt, kann die erlaubte Wiederholung folgen. Ein unklarer Ausgang hält den Lauf an. [1]',231)
box(M+123,340,261,55,'Offener Intent beim Resume','Kanonische Records vollständig prüfen')
arrow(W/2,396,W/2,419)
txt('Außenwirkung eindeutig feststellbar?',W/2,425,11,'Bold',TEAL,'center')
line(W/2,449,W/2,465);line(M+80,465,W-M-80,465)
for x,t,d,col,bg in [(M,'Erfolgt','Result abgleichen',TEAL,PALE),(M+175,'Nicht erfolgt','Erlaubt wiederholen',BLUE,PB),(M+350,'Unklar','Fail closed: Halt',AMBER,PA)]:
    arrow(x+78,465,x+78,489,col);box(x,495,157,61,t,d,col,bg)
caption(6,'Recovery-Entscheidung, schematisch. Für jeden Effekt gelten dessen eigene Abgleichregeln; „noch einmal starten“ ist kein allgemeiner Ersatz.',573)
y=body('Auch die Initialisierung ist streng begrenzt: Nur ein exakt zulässiger unvollständiger Baseline-Präfix darf vor jeder Außenwirkung vervollständigt werden. Fehlende Fakten in einem bereits aktiven Lauf werden nicht nachgetragen. So bleibt ein gut rekonstruierbarer Cacheverlust von einem nicht sicher rekonstruierbaren Faktenverlust getrennt. [1]',619)
body('Diese Architektur verspricht keine universelle Exactly-once-Ausführung beliebiger Außenwirkungen. Sie schafft explizite Wiederaufnahmegrenzen und stoppt bei Unsicherheit. Der reale Abbruch auf Seite 10 belegt einen konkreten SIGINT-/Resume-Pfad; der gesonderte Crash-Testbestand prüft weitere definierte Grenzen. Beides bleibt an getestete Fälle und Versionen gebunden.',y)
end()

# 10. Real case
header(10,'Fallstudie · RuhestandsApp','Ein echter Auftrag mit Abbruch','Auto-Optimize erhält einen eigenen Tab. Der Lauf verbindet normale Entwicklungsarbeit, eine absichtliche Unterbrechung und eine notwendige Korrektur.')
para('<b>Zielsystem:</b> RuhestandsApp, eine bestehende JavaScript-Anwendung mit Tauri-Desktopintegration. Ihre Regressionstestsuite meldete im abschließenden Lauf von <font name="Mono">npm test</font> <b>20.196 bestandene Assertions</b>. [3, 6]',M,221,CW,10.2,13.4,maxh=41)
box(M,280,235,62,'Vorher','Parameter-Sweep<br/>Sweep + Auto-Optimize',BLUE,PB)
box(M+272,280,235,62,'Nachher','Parameter-Sweep | Auto-Optimize<br/>Zwei getrennte Panels')
arrow(M+239,311,M+266,311)
para('Auftrag: vorhandenen Tab-Mechanismus und IDs erhalten; keine Änderung an Engine, Workern oder Optimierungslogik. Layouttests und Hilfe sollten den neuen Ort abbilden. [3, 6]',M,354,CW,10,13.4,maxh=28)
events=[
 ('14:23','Start','Ein Implementierungsslice auf der RuhestandsApp.'),
 ('14:28','Validierung rot','Ein bestehender Test erwartet weiterhin vier Tabs.'),
 ('14:29','Abbruch und Resume','SIGINT um 14:29:21; Resume ab 14:29:53.'),
 ('14:30','Review verweigert','R-01 fordert Klärung und Behebung der roten Suite.'),
 ('14:32-34','Vertrag und Scope','Unzulässige Antwort verworfen; zusätzliche Testdatei angefordert.'),
 ('14:37-38','Grün und abgeschlossen','npm test PASS; R-01 geschlossen; Gesamtreview ohne neue Findings.'),
]
for i,(t,h,s) in enumerate(events):
    yy=405+i*42
    txt(t,M,yy,8.7,'Mono',MUTED);dot(M+68,yy+5)
    if i<5:line(M+68,yy+10,M+68,yy+43)
    txt(h,M+83,yy-1,10,'Bold',INK)
    para(s,M+83,yy+14,CW-83,9.1,11.8,maxh=25)
para('Zeiten: 28.09.2026, Europe/Berlin. Beim Abbruch lief ein Claude-Review. Nach zwei Sekunden war der Orchestrator beendet; die anschließende Prozesskontrolle zeigte auch keinen verbleibenden Providerprozess. Resume kennzeichnete den alten Versuch als fehlgeschlagen und startete Versuch 2 derselben logischen Operation. [3]',M,668,CW,9.5,12.7,maxh=53)
para('<b>Nachweisgrenze:</b> Der separate Browser-Smoke war nicht Bestandteil der attestierten npm-test-Matrix. Das Abschlussreview hielt die verbleibende Unsicherheit zur Laufzeitinitialisierung fest. Der später erfolgte Merge erweitert diesen Testnachweis nicht.',M,728,CW,9.4,12.5,AMBER,maxh=39)
end()

# 11. Measures
header(11,'Umfang und Erfahrungen','Zahlen mit benanntem Nenner','Der Bestand ist groß genug für reale Integrationsprobleme. Zeilenzahlen messen Umfang und Pflegeaufwand, weder Qualität noch Nutzen.')
for x,n,t in [(M,'150.729','Python-Zeilen gesamt'),(M+176,'1,41 : 1','Testcode / src-Code'),(M+352,'2.884 + 39','bestandene Tests¹')]:
    txt(n,x,236,27,'Light',TEAL);txt(t,x,273,9.5,'Bold',MUTED)
y=table(['Gezählter Bestand','Dateien','Physische Zeilen'],[
 ['Produktivcode unter src/','80','61.441'],['Testcode unter tests/','113','86.755'],['Hilfsskripte unter scripts/','3','2.533'],
],[286,85,136],317,35)
para('Gezählt werden versionierte Python-Dateien im festgehaltenen Git-Baum, einschließlich Leerzeilen, Kommentaren und Docstrings. 86.755 / 61.441 = 1,412. Die Skripte stehen separat; mit ihnen im Produktivnenner beträgt das Verhältnis 1,36 : 1. Es handelt sich nicht um Testabdeckung. [1, 7]',M,y+13,CW,9.5,12.6,MUTED,maxh=53)
y=sub('Testnachweise und historische Einsätze',y+84)
y=body('¹ Die gespeicherten Phase-A-Protokolle melden 2.884 bestandene Tests in der Default-Suite und 39 bestandene Crash-Harness-Tests in einem separaten Lauf. Diese Zahlen wurden für das Papier aus vorhandenen Logs gelesen; es wurde keine neue Validierungsattestierung erzeugt. Der reale Funktionsnachweis referenziert den abgenommenen Feature-HEAD ausdrücklich. [3, 7]',y,size=10.2)
y=body('Eine frühere, fest besetzte Orchestratorversion implementierte eine vollständige Flutter-Anwendung aus einer vorgegebenen Spezifikation. Dabei waren zwei bis drei Rückfragen erforderlich. Das anonymisierte Beispiel veranschaulicht einen früheren Entwicklungseinsatz außerhalb der Phase-A-Abnahme; Projektname, Domäne und Spezifikationsdetails bleiben unveröffentlicht. [8]',y,size=10.2)
body('Weitere Einsätze umfassten Fehlerbehebung in der RuhestandsApp und Bootstrap-Arbeiten am Orchestrator. Die Phase-A-Entwicklung zeigt zugleich den Aufwand: Übersehene Bindungen und ein Fehler beim Schreiben großer Prompts wurden im Review erkannt und vor der Abnahme korrigiert. Selbstverbesserung braucht dieselben Prüfgrenzen wie Änderungen an einer fremden Anwendung. [5, 8]',y,size=10.2)
end()

# 12. Subscription economics
header(12,'Betriebsmodell','Zeit kann Budget ersetzen','Quota-Grenzen sind Teil des Betriebs: Der Orchestrator kann auf erneute Verfügbarkeit warten und die Arbeit anschließend fortsetzen.')
y=body('Die Größe eines Providerkontingents bestimmt, wie viel Arbeit zwischen zwei Pausen möglich ist. Erreicht ein unterstützter Provider sein Nutzungslimit, hält der Orchestrator den Ablauf an. Aus einer eindeutig erkannten Reset-Zeit plant er die Wiederaufnahme und wartet bis zu diesem Zeitpunkt zuzüglich Sicherheitsabstand. Anschließend setzt er die unterbrochene Arbeit fort, sofern die Resume-Prüfungen erfüllt sind. So können auch kleine Abokontingente für längere Aufgaben genutzt werden. [1]',231)
box(M,364,151,72,'Arbeiten','Gebundener Provider<br/>liefert Ergebnisse',BLUE,PB)
box(M+178,364,151,72,'Quota erreicht','Wartezustand mit<br/>Wiederaufnahmezeit',AMBER,PA)
box(M+356,364,151,72,'Fortsetzen','Bindungen prüfen;<br/>Arbeit wiederaufnehmen')
arrow(M+153,400,M+173,400);arrow(M+331,400,M+351,400)
caption(7,'Schematischer Quota-Pfad. Während der Pause bleiben Arbeitsstand, Rollenprofile und Prüfregeln erhalten.',451)
y=body('Die Quota-Erkennung wertet die Meldungen der unterstützten Provider aus. Eindeutige Reset-Zeiten werden auf UTC normalisiert; maximale Wartezeit, Sicherheitsabstand und Zahl automatischer Wiederaufnahmen sind konfigurierbar. Fehlt eine eindeutige Reset-Zeit oder ist eine konfigurierte Grenze erreicht, bleibt der Lauf für eine explizite Wiederaufnahme angehalten. Die Kontrollregeln für Review, Validierung und Commit gelten auch nach der Pause unverändert. [1]',502)
y=body('Die offiziellen Anbieterunterlagen unterscheiden Zugangswege: Codex unterstützt für lokale Arbeit die Anmeldung über ChatGPT oder einen API-Schlüssel. Claude Code kann Pro-/Max-Kontingente nutzen; Limits werden mit weiterer Claude-Nutzung geteilt. Separat gewählte API-Nutzung wird separat abgerechnet. Diese Wahl betrifft die Authentifizierung und Abrechnung der jeweiligen CLI. Sie bedeutet keinen bereits implementierten direkten HTTP-API-Adapter im Orchestrator. [9, 10]',y)
callout('Praktische Konsequenz','Preiswerte Abos werden nutzbar, wenn Aufgaben über mehrere Kontingentfenster laufen dürfen. Wer kürzere Durchlaufzeiten benötigt, kann größere Kontingente oder API-Abrechnung wählen. Die gewählte Zugangsart bestimmt das verfügbare Budget; die Prüfregeln bleiben dieselben.',y+2,80)
end()

# 13. Related work and boundaries
header(13,'Einordnung und Ausblick','Bekannte Bausteine, eigener Fokus','Der Beitrag liegt in der konkreten Verbindung und Durchsetzung der Verträge. Die Architektur beansprucht keine Erfindung des Vier-Augen-Prinzips oder von Event Sourcing.')
y=body('<b>ESAA</b> beschreibt Event Sourcing für autonome Agenten und umfasst eine Implementierung sowie zwei Fallstudien. Gemeinsam sind die explizite Ereignishistorie, der rekonstruierbare Zustand und die Trennung von Vorgängen und Projektionen. Mit ESAA-Core existiert zudem ein Softwareprojekt. Die verwandten Ansätze haben damit sowohl eine konzeptionelle als auch eine praktische Grundlage. [11]',231)
y=body('Der praktische Schwerpunkt des <b>Dual-Agent-Orchestrators</b> liegt in den Betriebsgrenzen eines Entwicklungsworkflows auf Git-Repositories: heterogene Provider-JSON-Dialekte, reviewer-eigene Findings, fingerprintgebundene Validierung sowie kontrollierte Git- und Dateisystemwirkungen. Prozessunterbrechungen und Resume müssen diese Bindungen unter Linux beziehungsweise WSL 2 erhalten. Dafür verbindet Phase A konkrete Mechanismen mit Tests und einem realen Abnahmelauf. [1, 3, 5]',y)
y=body('<b>LangGraph</b> dokumentiert Checkpoints, Zustandsinspektion und Wiederaufnahme. <b>Anthropic</b> beschreibt das Evaluator-Optimizer-Muster als wiederholte Erzeugung und Bewertung. Diese Einordnung benennt verwandte Bausteine; ein Qualitätsvorsprung gegenüber ESAA oder anderen Ansätzen wurde nicht vergleichend gemessen. [11, 12, 13]',y)
y=sub('Was offen bleibt',y+6)
y=body('Die reale Abnahme umfasst einen überschaubaren UI-Umbau mit einer aktuellen Providerbesetzung. Für Erfolgsquoten, mittlere Korrekturrunden, Warteanteil und Kosten je abgeschlossener Aufgabe fehlt eine ausreichend breite Messreihe. Mehr Testcode ist kein Ersatz dafür. Auch Herstellertrennung garantiert keine statistische Unabhängigkeit: Modelle können dieselben Annahmen teilen oder denselben Fehler übersehen.',y)
y=body('Die nächste Providerintegration muss Rechte und Konfigurationsisolation praktisch angreifen, Schema- und Transportgrenzen nachweisen und die Zielrolle in vorab festgelegten Fällen prüfen. Die Phase-B-Planung fordert dabei denselben Isolationsmaßstab auch für den bestehenden Claude-Reviewer. Ein erfolgreicher PoC oder das bloße Entfernen eines Provider-Pins genügt nicht. [4]',y)
callout('Die nächste sinnvolle Messreihe','Mehrere reale Aufgaben je zugelassener Topologie: Abschlussstatus, Findings, Korrekturen, Vertragsfehler, aktive Laufzeit, Quota-Wartezeit und tatsächlicher Verbrauch. Vorab definierte Fälle und vollständig sichtbare Fehlversuche machen die Ergebnisse vergleichbar.',y+3,82)
end()

# 14. Sources
header(14,'Quellen und Methode','Nachvollziehbar bis zum Stand','Quellenstand: 28. September 2026. Repositorybezüge sind auf den beschriebenen Stand fixiert; externe Dokumentation kann sich später ändern.')
GH='https://github.com/dieteresser62-lab/Dual-Agent-Orchestrator'
COMMIT='adf1411b2f7cba87a4edee52dfed7d29e657a24f'
def link(title,url):return '<link href="'+escape(url)+'" color="'+TEAL+'">'+escape(title)+'</link>'
sources=[
 ('1',link('Phase-A-Code und Rollenvertrag',GH+'/tree/'+COMMIT)+'. Abgenommener Stand vom 28.09.2026: AGENTS.md, src/, schemas/ und README.md. Versionbindung und Nachweise: docs/reference/whitepaper-phase-a-evidenz.md im Repository.'),
 ('2',link('Rollenfreigaben und Konfiguration',GH+'/blob/'+COMMIT+'/schemas/role-provider-certifications-v1.json')+'. Dazu orchestrator.toml: Slots, Profile, Workflowlimits.'),
 ('3','Lokales Abnahmepaket: Start-/Endmetadaten, Abbruchprotokoll, Resume-Log und strukturierte Records. Der gespeicherte npm-test-Output meldet 20.196 bestandene Assertions. Testoutput mitveröffentlicht; übriges Rohpaket lokal eingesehen.'),
 ('4','Lokale Planung „Task B - Antigravity als zusätzlicher Reviewer“ und „Task C - Freie Rollenbesetzung nach Kombination qualifizieren“, 27.09.2026. Eingesehene Planungsunterlagen, keine bereits implementierte Unterstützung.'),
 ('5','Lokaler Antigravity-PoC-Bericht vom 27.09.2026 sowie Entscheidungsprotokoll und Branchreview der Phase-A-Steuerung. Entwicklungsbefunde, kein Leistungsbenchmark. Originalunterlagen nicht mitveröffentlicht.'),
 ('6',link('RuhestandsApp: Implementierung des neuen Tabs','https://github.com/dieteresser62-lab/Ruhestand-App-Final/commit/1580308377fb55907efa18f6586b566eb67953c0')+'. Quelländerungen, Tests und Dokumentation zur Trennung von Parameter-Sweep und Auto-Optimize.'),
 ('7','Eigene Bestandszählung aus dem fixierten Git-Baum: git archive, nur *.py in src/, tests/, scripts/, physische Zeilen via splitlines(). Mitveröffentlichte task-a-default.log / task-a-crash.log: 2.884 / 39 PASS. Fundorte und Prüfsummen im Evidenzindex; keine neue Attestierung.'),
 ('8','Projektgeschichte und frühere Anwendungseinsätze: Markdown-Kommunikation, anonymisierte Flutter-Implementierung, Fehlerbehebung und Bootstrap. Beschreibende Fallbeispiele außerhalb der formalen Phase-A-Abnahme.'),
 ('9',link('OpenAI: Authentication','https://learn.chatgpt.com/docs/auth')+'. Offizielle Beschreibung von Abo- und API-Anmeldung für Codex; Abruf 28.09.2026.'),
 ('10',link('Anthropic: Claude Code mit Pro oder Max','https://support.claude.com/en/articles/11145838-use-claude-code-with-your-pro-or-max-plan')+'. Offizielle Beschreibung von gemeinsamem Kontingent, Reset und separater API-Abrechnung; Abruf 28.09.2026.'),
 ('11',link('ESAA: Event Sourcing for Autonomous Agents in LLM-Based Software Engineering','https://arxiv.org/abs/2602.23193')+'. Elzo Brito dos Santos Filho, 2026, arXiv:2602.23193. Preprint mit Implementierung und Fallstudien; '+link('ESAA-Core','https://github.com/elzobrito/ESAA-Core')+' als Softwareprojekt.'),
 ('12',link('LangGraph: Persistence','https://docs.langchain.com/oss/python/langgraph/persistence')+'. Offizielle Dokumentation zu Checkpoints und Wiederaufnahme; Abruf 28.09.2026.'),
 ('13',link('Anthropic: Building effective agents','https://www.anthropic.com/engineering/building-effective-agents')+'. Evaluator-Optimizer als Workflowmuster; Abruf 28.09.2026.'),
 ('14',link('Google: Antigravity CLI','https://github.com/google-antigravity/antigravity-cli')+'. Offizielle Beschreibung des terminalbasierten Agentenwerkzeugs und des Aufrufs agy; Abruf 28.09.2026.'),
]
y=228
for n,s in sources:
    txt('['+n+']',M,y+1,8.6,'Bold',TEAL)
    y=para(s,M+27,y,CW-27,9.05,12.1,maxh=39)+9
end();c.save()

reader=PdfReader(PDF)
assert len(reader.pages)==14
(ROOT/'source'/'textauszug.md').write_text('# Stochastische Agenten, deterministische Kontrolle\n\nArchitektur-Whitepaper, Phase A · 28.09.2026\n\nRedaktioneller Absatztext. Die vollständige, bearbeitbare Fassung einschließlich Tabellen, Bildbeschriftungen und Layout steht in build_whitepaper.py.\n\n'+'\n\n'.join(TEXT)+'\n',encoding='utf-8')
(TMP/'text-boxes.json').write_text(json.dumps(BOXES,ensure_ascii=False,indent=2),encoding='utf-8')
full='\n'.join(p.extract_text() or '' for p in reader.pages)
(TMP/'extracted.txt').write_text(full,encoding='utf-8')
print(json.dumps({'pdf':str(PDF),'pages':len(reader.pages),'words':len(full.split()),'bytes':PDF.stat().st_size,'sha256':hashlib.sha256(PDF.read_bytes()).hexdigest()},ensure_ascii=False))
