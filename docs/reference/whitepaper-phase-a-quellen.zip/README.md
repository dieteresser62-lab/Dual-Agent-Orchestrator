# Architektur-Whitepaper: Phase A

**Stochastische Agenten, deterministische Kontrolle**

14 Seiten, Ausgabe 1.3, Stand 28.09.2026. Das Papier dokumentiert die abgenommene Phase A, den RuhestandsApp-Abnahmelauf und die damals geplanten Erweiterungen B/C. Spätere Nacharbeiten verändern diese historische Versionbindung nicht.

Ausgabe 1.3 trennt den Protokollmodus von Artefakt- und Nachrichtenschemas, benennt die fünf Profildigests genau, ergänzt den vollständigen ESAA-Titel und macht die Testnachweise dauerhaft zugänglich. Die in Ausgabe 1.2 ergänzten Erläuterungen zu Anwendungskontext, unabhängiger Validierung, Fehlerfortschreibung und verwandten Arbeiten sind enthalten.

## Dateien

- `output/pdf/architektur-whitepaper-phase-a.pdf`: gestaltete Fassung mit eingebetteten Schriften, Vektordiagrammen, Lesezeichen und Quellenlinks.
- `source/build_whitepaper.py`: vollständige bearbeitbare Quelle einschließlich Texten, Tabellen und Vektorgrafiken.
- `source/textauszug.md`: automatisch erzeugter Absatztext; Tabellen- und Diagrammbeschriftungen stehen vollständig im Generator.
- `source/architektur.puml`, `source/reviewablauf.puml`, `source/recovery.puml`: semantische PlantUML-Fassungen. Die PDF-Grafiken setzt der Generator direkt; PlantUML ist kein Build-Werkzeug für diese PDF.
- `source/evidence.json`: Fakten, Versionbindung und Nachweisgrenzen.
- `source/published-evidence.json`: Herkunfts- und Veröffentlichungsprüfsummen der drei Testlogs einschließlich der dokumentierten Anonymisierung.
- `source/measure_code.py`: reproduzierbare Bestandszählung aus einem Git-Commit.
- `evidence/`: öffentliche Kopien der Testprotokolle.
- `whitepaper-phase-a-evidenz.md`: lesbarer Evidenzindex in seiner Repository-Fassung; seine relativen Links beziehen sich auf `docs/reference/`.
- `SHA256SUMS.txt`: Prüfsummen sämtlicher Ausgabedateien dieses Pakets außer der Prüfsummendatei selbst.

## Bearbeiten und neu erzeugen

Das Quellen-ZIP an einen frei gewählten Arbeitsort entpacken. Texte und Layout werden in `source/build_whitepaper.py` gepflegt; `source/textauszug.md` wird beim Build überschrieben. Das Skript verändert keine Orchestratorzustände und startet weder Provider noch Tests.

Voraussetzungen: Python mit `reportlab` und `pypdf`. Die geprüfte Ausgabe wurde mit ReportLab 4.4.9 erzeugt. Für das identische Schriftbild werden Calibri, Segoe UI und Consolas benötigt; die Schriften werden nicht mitverteilt. Der Generator sucht automatisch in `C:/Windows/Fonts` und unter WSL in `/mnt/c/Windows/Fonts`. Ein anderes lokales Schriftverzeichnis kann über `--font-dir` angegeben werden.

Vom entpackten Paketverzeichnis:

```text
python source/build_whitepaper.py
```

Optionaler Zielpfad und explizites Schriftverzeichnis unter WSL:

```text
python3 source/build_whitepaper.py --font-dir /mnt/c/Windows/Fonts --output /home/dieter/repos/Dual-Agent-Orchestrator/docs/reference/architektur-whitepaper-phase-a.pdf
```

Ohne `--output` entsteht die PDF unter `output/pdf/`. Der Generator prüft feste Textboxhöhen und erzeugt Layoutdaten unter `tmp/pdfs/`. Nach Änderungen die PDF mit Poppler rendern und alle betroffenen Seiten visuell prüfen. Die eingebetteten Schriftdateien und Grafiken machen die fertige PDF unabhängig von lokal installierten Schriften.

Die geprüfte Fassung verwendet feste Seitenumbrüche; identische Inhalte und Gestaltung bedeuten wegen PDF-Metadaten nicht zwingend einen identischen Datei-Hash bei jedem Neuaufbau.

## Repository-Ablage

Unter `docs/reference/` liegen PDF, `whitepaper-phase-a-evidenz.md`, `whitepaper-phase-a-evidence/` und `whitepaper-phase-a-quellen.zip`. Das ZIP enthält alle hier genannten Quellen. Es hält die Publikationsquelle mit ihrem historischen Provider-Ausblick als geschlossene Ausgabe zusammen. Für eine Folgeausgabe das Paket entpacken, bearbeiten, neu bauen und als neue Ausgabe bündeln.

## Evidenz und Veröffentlichung

Die Prüfsummen unterscheiden Originale und öffentliche Kopien. Im Default-Testlog wurde genau ein fremder Projektname in einem Testbezeichner durch `anonymized_project` ersetzt. Ergebnisse und Testanzahl sind unverändert. Crash-Log und npm-Testoutput wurden bytegleich übernommen. Unveränderte Originale sind zusätzlich im privaten Abnahmepaket gesichert.

Die übrigen Abnahme-, Entwicklungs- und Planungsunterlagen wurden eingesehen, aber nicht als Rohpaket beigefügt. Der Evidenzindex nennt diese Grenze ausdrücklich; die veröffentlichte Sammlung ist weder eine neue Orchestratorattestierung noch eine vollständige Replay-Verifikation.

Die historische Flutter-Fallstudie bleibt anonymisiert. Projektname, Domäne, Spezifikation, Originalpfade und identifizierende Verweise werden nicht mitveröffentlicht. Das Abo-Kapitel beschreibt Quota-Erkennung, Wartebedingungen und kontrollierte Wiederaufnahme ohne persönliche Ausgaben oder Tarifpreise.
