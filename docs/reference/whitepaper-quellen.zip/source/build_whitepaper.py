"""Architecture whitepaper, completed phases A–C. Vector figures, embedded fonts, explicit pages.
Build: python source/build_whitepaper.py
Dependencies: reportlab, pypdf. Fonts: Calibri, Segoe UI, Consolas (Windows or locally available TTF files).
Sources and measurement method are documented in the paper and evidence.json.
"""
from pathlib import Path
from math import atan2, cos, sin
from xml.sax.saxutils import escape
import re, json, hashlib, argparse
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,help='Destination PDF; default: output/pdf/architektur-whitepaper.pdf')
parser.add_argument('--font-dir',type=Path,help='Directory containing Calibri, Segoe UI and Consolas TTF files')
args=parser.parse_args()
PDF=args.output or ROOT/'output'/'pdf'/'architektur-whitepaper.pdf'
fonts=[('Body','calibri.ttf'),('Bold','calibrib.ttf'),('Italic','calibrii.ttf'),('Display','segoeuib.ttf'),('Light','segoeuil.ttf'),('Mono','consola.ttf')]
candidates=[args.font_dir] if args.font_dir else [Path('C:/Windows/Fonts'),Path('/mnt/c/Windows/Fonts')]
font_dir=next((d for d in candidates if all((d/f).is_file() for _,f in fonts)),None)
if font_dir is None:
    parser.error('Required font files not found; supply --font-dir. No font files are redistributed.')
PDF.parent.mkdir(parents=True,exist_ok=True)
TMP=ROOT/'tmp'/'pdfs'; TMP.mkdir(parents=True,exist_ok=True)
for n,f in fonts:
    pdfmetrics.registerFont(TTFont(n,str(font_dir/f)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Italic',boldItalic='Bold')
W,H=A4; M=44; CW=W-2*M
INK='#152F3D'; NAVY='#102936'; TEAL='#007D79'; MINT='#6DD8C1'
BLUE='#3E6F9D'; PURPLE='#7D6495'; AMBER='#AA682C'; PAPER='#F8F7F3'
WHITE='#FFFFFF'; MUTED='#576B75'; LINE='#CAD5D7'; PALE='#EAF0EF'
PB='#EDF2F7'; PP='#F1EDF5'; PA='#F5EDE3'
c=canvas.Canvas(str(PDF),pagesize=A4,pageCompression=1)
c.setTitle('Stochastische Agenten, deterministische Kontrolle - Architektur-Whitepaper, Phasen A–C')
c.setAuthor('Dieter Esser | Dual-Agent-Orchestrator')
c.setSubject('Rollenverträge, Providergrenzen, Records und Betriebsnachweise. Stand 01.10.2026.')
TEXT=[]; BOXES=[]

def rect(x,y,w,h,color,edge=None,r=0):
    c.setFillColor(HexColor(color));c.setLineWidth(.7)
    if edge:c.setStrokeColor(HexColor(edge))
    if r:c.roundRect(x,H-y-h,w,h,r,fill=1,stroke=bool(edge))
    else:c.rect(x,H-y-h,w,h,fill=1,stroke=bool(edge))
def line(x,y,xx,yy,color=LINE,width=.7,dash=None):
    c.setStrokeColor(HexColor(color));c.setLineWidth(width);c.setDash(dash or [])
    c.line(x,H-y,xx,H-yy);c.setDash([])
def txt(s,x,y,size=10,font='Body',color=INK,align='left'):
    c.setFillColor(HexColor(color));c.setFont(font,size)
    if align=='center':c.drawCentredString(x,H-y-size*.82,s)
    elif align=='right':c.drawRightString(x,H-y-size*.82,s)
    else:c.drawString(x,H-y-size*.82,s)
    w=pdfmetrics.stringWidth(s,font,size)
    if align=='left' and (x<0 or x+w>W+.1):raise ValueError('Text too wide: '+s)
def para(s,x,y,w,size=10.6,leading=14.4,color=INK,font='Body',maxh=None,record=True):
    p=Paragraph(s,ParagraphStyle('p',fontName=font,fontSize=size,leading=leading,textColor=HexColor(color),allowWidows=0,allowOrphans=0))
    _,h=p.wrap(w,H)
    if maxh is not None and h>maxh+.1:raise ValueError(f'Page {c.getPageNumber()}: {h}>{maxh}: '+s[:70])
    if y+h>H-65:raise ValueError(f'Page {c.getPageNumber()} text too low ({y+h}): '+s[:70])
    p.drawOn(c,x,H-y-h)
    BOXES.append({'page':c.getPageNumber(),'x':x,'y':y,'w':w,'h':h,'text':s})
    if record:TEXT.append(re.sub('<[^>]+>','',s).replace('&amp;','&').replace('&lt;','<').replace('&gt;','>'))
    return y+h
def body(s,y,w=CW,x=M,size=10.6):return para(s,x,y,w,size,size*1.36)+11
def label(s,x,y,color=TEAL,size=8):txt(s,x,y,size,'Bold',color)
def sub(s,y,x=M):txt(s,x,y,13,'Display',INK);TEXT.append('\n### '+s);return y+24
def arrow(x,y,xx,yy,color=TEAL,dashed=False):
    line(x,y,xx,yy,color,1.05,[3,3] if dashed else None)
    a=atan2(yy-y,xx-x)
    line(xx-6*cos(a-.45),yy-6*sin(a-.45),xx,yy,color,1.05)
    line(xx-6*cos(a+.45),yy-6*sin(a+.45),xx,yy,color,1.05)
def dot(x,y,r=3,color=TEAL):
    c.setFillColor(HexColor(color));c.circle(x,H-y,r,fill=1,stroke=0)
def box(x,y,w,h,title,detail='',color=TEAL,bg=PALE):
    rect(x,y,w,h,bg,LINE,5);rect(x,y,3,h,color)
    dh=0
    if detail:
        pp=Paragraph(detail,ParagraphStyle('measure',fontName='Body',fontSize=9.2,leading=12.2))
        _,dh=pp.wrap(w-24,H)
    block=10.2+(9+dh if detail else 0)
    offset=(h-block)/2
    if offset<8:raise ValueError('Box content needs more space: '+title)
    txt(title,x+12,y+offset,10.2,'Bold',color)
    if detail:para(detail,x+12,y+offset+19.2,w-24,9.2,12.2,maxh=dh+.1)
def callout(title,s,y,h=84,color=TEAL,bg=PALE):
    rect(M,y,CW,h,bg,r=5);rect(M,y,3,h,color)
    label(title.upper(),M+14,y+12,color)
    para(s,M+14,y+30,CW-28,10.2,14,maxh=h-38)
def caption(n,s,y):
    label(f'ABB. {n:02d}',M,y)
    para(s,M+48,y-1,CW-48,8.8,11.6,MUTED,maxh=38)
def footer(n,dark=False):
    fg='#B0C4CB' if dark else MUTED
    line(M,790,W-M,790,'#3A5563' if dark else LINE)
    txt('DUAL-AGENT-ORCHESTRATOR',M,803,7.1,'Bold',fg)
    txt('PHASEN A–C  /  01.10.2026',W/2,803,7.1,'Body',fg,'center')
    txt(f'{n:02d} / 15',W-M,802,8,'Mono',fg,'right')
def header(n,section,title,deck):
    rect(0,0,W,H,PAPER);label('ARCHITEKTUR / WHITEPAPER',M,29,MUTED)
    label('A–C · V2.2',W-M-77,29,TEAL)
    line(M,56,W-M,56);txt(f'{n-1:02d}',M,77,32,'Light',TEAL)
    label(section.upper(),M+55,84)
    txt(title,M,122,26,'Display')
    para(deck,M,168,CW,11.3,15.3,MUTED,maxh=47,record=False)
    TEXT.append('\n## '+title+'\n\n'+deck)
    c.bookmarkPage('page'+str(n));c.addOutlineEntry(title,'page'+str(n),level=0)
    footer(n)
def end():c.showPage()
def table(headers,rows,widths,y,rowh=39):
    x=M;rect(M,y,CW,29,NAVY)
    for h,w in zip(headers,widths):txt(h,x+9,y+10,8.7,'Bold',WHITE);x+=w
    yy=y+29
    for i,row in enumerate(rows):
        rect(M,yy,CW,rowh,WHITE if i%2==0 else PALE)
        x=M
        for cell,w in zip(row,widths):para(cell,x+9,yy+9,w-18,9.4,12.2,maxh=rowh-14);x+=w
        yy+=rowh
    line(M,yy,W-M,yy)
    return yy


# 1. Cover
rect(0,0,W,H,NAVY)
label('DUAL-AGENT-ORCHESTRATOR',M,35,MINT,9)
label('ARCHITEKTUR / AUSGABE 2.2',W-M-146,35,MINT,8)
line(M,66,W-M,66,'#3A5563')
label('ROLLENTRENNUNG, PROVIDERWECHSEL UND PRÜFBARE ABLÄUFE',M,99,'#B4CACF',8.5)
txt('Stochastische',M,133,41,'Display',WHITE)
txt('Agenten,',M,183,41,'Display',WHITE)
txt('deterministische',M,251,36.5,'Light',MINT)
txt('Kontrolle.',M,297,41,'Display',MINT)
para('Eine Architektur für agentische Softwareentwicklung mit getrennten Befugnissen, austauschbaren Providern und kontrollierter Wiederaufnahme.',M,365,455,14,19,'#D7E4E6',maxh=63)
for x,w,t in [(M,123,'Gebundene Rollen'),(M+157,166,'Deterministische Gates'),(M+356,151,'Prüfbare Records')]:
 rect(x,464,w,51,'#24404C',r=5);txt(t,x+w/2,483,9.7,'Bold',MINT,'center')
arrow(M+125,490,M+150,490,MINT);arrow(M+325,490,M+350,490,MINT)
rect(0,572,W,189,PAPER);label('DOKUMENTIERTER STAND',M,593)
para('Phasen A–C abgeschlossen: Codex / Claude / Claude als Standard; Claude / Codex / Codex experimentell zugelassen und im vollständigen Workflow erprobt.',M,617,CW,14,19,maxh=62)
txt('Dieter Esser',M,704,11,'Bold')
txt('Technisches Whitepaper · Ausgabe 2.2 · 1. Oktober 2026',M,725,9.5,'Body',MUTED)
footer(1,True);end()

# 2. Abstract
header(2,'Zusammenfassung','Die Rolle bestimmt den Vertrag','Die Phasen A–C verbinden ein neutrales Rollenmodell mit konkreten Adaptergrenzen, Qualifikationsnachweisen und realen Entwicklungsabläufen.')
y=body('Der Dual-Agent-Orchestrator organisiert Softwareänderungen als kontrollierten Prozess. Ein <b>Implementer</b> plant, implementiert und korrigiert; ein davon getrennter <b>Reviewer</b> bewertet Plan und Umsetzung. Der Orchestrator führt die maßgebliche Validierung aus, bindet ihre Ergebnisse an den geprüften Stand und entscheidet anhand expliziter Regeln über Zustandsübergänge und Git-Transaktionen. [1]',231)
y=body('Drei konfigurierbare Slots besetzen Implementierung, laufendes Review und abschließendes Branchreview. Der Finalreviewer ist eine weitere Reviewer-Aufgabe, keine dritte fachliche Rolle. Provider, Modell, Aufwand, Laufzeitgrenze und Berechtigungen gehören zum gebundenen Profil. Die fachlichen Regeln bleiben beim Rollenwechsel erhalten. [1, 2]',y)
callout('Praktisch nachgewiesen','Die Standardbesetzung Codex / Claude / Claude und die umgekehrte Besetzung Claude / Codex / Codex durchlaufen denselben Workflow. Die neue Besetzung ist experimentell freigegeben; ihre Messgrenzen sind Teil des Nachweises.',y+2,88)
y=sub('Was die drei Phasen beigetragen haben',y+110)
y=body('<b>Phase A</b> trennt Rollen und Provider sowie fachlichen Vertrag und JSON-Transport. <b>Phase B</b> erprobt eine zusätzliche Reviewer-Integration. <b>Phase C</b> macht die Zulassung je Slot allgemeiner und ergänzt Codex als Reviewer sowie Claude als Implementer. Der praktische Schwerpunkt dieser Ausgabe liegt auf OpenAI und Anthropic. [1, 2, 4, 5]',y)
y=body('Die Ausgabe fixiert den veröffentlichten Stand vom 1. Oktober 2026. Die einzelnen Live-Messungen entstanden auf benannten Entwicklungsständen; sie sind kein gemeinsamer Testlauf auf dem letzten Veröffentlichungscommit. Unterstützter Rahmen ist Linux beziehungsweise WSL 2; die neuen Qualifikationen wurden unter WSL 2 / Ubuntu / ext4 durchgeführt. Exakte Versionsbindungen stehen im begleitenden Evidenzindex. [8]',y,size=10.2)
line(M,724,W-M,724)
para('LESERWEG   Architektur und Rollen S. 3–6 · Providerverträge und Recovery S. 7–9<br/>Qualifikation und Fallstudien S. 10–12 · Betrieb, Einordnung und Quellen S. 13–15',M,738,CW,9.3,12.4,MUTED,maxh=27)
end()

# 3. Deterministic guards
header(3,'Problem und Prinzip','Warum Schranken nötig sind','Stochastische Ergebnisse werden erst durch überprüfte Bindungen und explizite Übergangsregeln zu einem kontrollierten Entwicklungsprozess.')
y=body('Ein LLM kann dieselbe Aufgabe unterschiedlich interpretieren, Voraussetzungen übersehen oder einen plausiblen, aber falschen Abschluss melden. In langen Abläufen kann eine unbemerkte Annahme zum Ausgangspunkt weiterer Änderungen werden. Sprachliche Überzeugungskraft ist deshalb keine ausreichende Freigabebedingung.',231)
y=body('Die Entwicklung begann mit Kommunikation über Markdown-Dateien. Deren wechselnde Struktur erschwerte eine verlässliche maschinelle Auswertung. Die JSON-Schicht schafft einen prüfbaren Formvertrag; der Rollenvertrag bestimmt zusätzlich, welche Aussage in welchem Zustand von welchem Akteur stammen darf. Die Projektion als Markdown bleibt eine Ansicht für Menschen. [1, 9]',y)
for x,t,d,col,bg in [(M,'1 · Form','Native JSON-Antwort;<br/>Schema vollständig erfüllt',BLUE,PB),(M+175,'2 · Bindung','Request, Rolle und Stand<br/>passen zum Auftrag',PURPLE,PP),(M+350,'3 · Übergang','Befunde, Evidenz und Policy<br/>erlauben den nächsten Schritt',TEAL,PALE)]:box(x,414,157,77,t,d,col,bg)
caption(1,'Drei unterschiedliche Prüfebenen. Eine formal gültige Antwort kann fachlich oder im Workflow unzulässig sein.',510)
y=sub('Fehlerfortschreibung begrenzen',557)
y=body('Ungültige Antworten werden verworfen. Korrigierbare Vertragsfehler können eine neue, gebundene Anfrage mit präziser Rückmeldung auslösen; die ursprüngliche Antwort wird dadurch nicht gültig. Freitext-Reparatur und ein Rückfall auf Markdown-Parsing gehören nicht zum Vertragsweg. [1, 3]',y)
y=body('Deterministische Tests prüfen definierte Eigenschaften. Ein unabhängiges Review prüft darüber hinaus Verträge, Fehlerpfade und Annahmen. Beides kann Lücken haben: Die Architektur kontrolliert, welche Evidenz eine Entscheidung tragen darf; sie garantiert keine vollständige fachliche Fehlerfreiheit.',y)
callout('Der entscheidende Unterschied','Ein Modell liefert einen Vorschlag oder ein Urteil. Verbindlich wird ein Zustandsübergang erst, wenn der Orchestrator die dazugehörigen Bedingungen geprüft hat.',y+1,75)
end()

# 4. Components
header(4,'Komponenten und Befugnisse','Eine kleine Autoritätsgrenze','Vereinfachtes UML-Komponentendiagramm: fachliche Rollen, technische Steuerung und dauerhafte Fakten haben unterschiedliche Zuständigkeiten.')
box(M,231,236,90,'«component» Implementer','Planen · implementieren · korrigieren<br/>Arbeitsbereich im gebundenen Profil',BLUE,PB)
box(M+271,231,236,90,'«component» Reviewer','Plan · Slice · Gesamtbranch prüfen<br/>Keine Produktänderung oder Selbstvalidierung',PURPLE,PP)
box(M+122,395,263,87,'«component» Orchestrator','Requestbindung · Domainprüfung · Policy<br/>Validierung · Zustandsübergänge · Git')
arrow(M+118,323,M+189,389,BLUE);arrow(M+389,323,M+320,389,PURPLE)
txt('Ergebnis / Disposition',M+9,346,8.8,'Body',BLUE);txt('Urteil / Finding',M+375,355,8.8,'Body',PURPLE)
box(M,532,236,67,'«artifact» Validierung','Ausgeführt durch die Steuerung;<br/>an den Änderungsstand gebunden')
box(M+271,532,236,67,'«artifact» Record Store','Append-only Fakten und Referenzen;<br/>Quelle für Replay und Audit')
arrow(M+183,484,M+118,526);arrow(M+323,484,M+389,526)
caption(2,'Der Reviewer kann eine Änderung zurückweisen. Er darf weder den Produktcode korrigieren noch die maßgebliche Validierungsattestierung erzeugen.',615)
y=body('Der Reviewer erhält Snapshot, Request, Schema und Evidenz. Beim Codex-Reviewer begrenzen Rechteprofil und Modellkatalog Pfade und Werkzeuge. Für Claude als Implementer wirken Sandbox-Schreibgrenzen und der Schutzbaum-Fingerprint zusammen. Eine verweigerte Werkzeugaktion beendet den Lauf nicht automatisch; maßgeblich ist ihre Klassifikation. [3, 4, 5]',664,size=10)
body('Die Ablehnungsregel unterscheidet sichtbare verbotene Aktionen, ausdrücklich tolerierte unbestimmbare Ziele und weiterhin stoppende Fehlerklassen (S. 14). Dateimodi allein sind keine vollständige Isolation; die Nachweise gelten für die geprüften Profile und Fälle.',y,size=10)
end()

# 5. Sequence
header(5,'Vier-Augen-Prinzip','Review ist ein eigener Prozess','UML-Sequenzdiagramm für einen Slice. Urteil und Commit bleiben getrennt; beide Providerbesetzungen verwenden dieselben fachlichen Übergänge.')
xs=[M+63,M+252,M+443]
for x,t,col,bg in zip(xs,['Implementer','Orchestrator','Reviewer'],[BLUE,TEAL,PURPLE],[PB,PALE,PP]):
 rect(x-57,230,114,33,bg,LINE,4);txt(t,x,242,9.5,'Bold',col,'center');line(x,267,x,568,LINE,.8,[3,3])
events=[(280,1,0,'Planauftrag',TEAL),(315,0,1,'Gebundener Plan',BLUE),(350,1,2,'Plan + Vertrag + Evidenz',TEAL),(385,2,1,'Planfreigabe / Befunde',PURPLE),(420,1,0,'Umsetzung / Korrektur',TEAL),(455,0,1,'Änderung + Dispositionen',BLUE),(527,1,2,'Änderung + Attestierung',TEAL),(562,2,1,'Freigabe / Ablehnung',PURPLE)]
for y,a,b,t,col in events:
 arrow(xs[a],y,xs[b],y,col);txt(t,(xs[a]+xs[b])/2,y-15,8.6,'Body',col,'center')
rect(xs[1]-77,469,154,26,PALE,LINE,3);txt('Validierung am Änderungsstand',xs[1],478,8.4,'Bold',TEAL,'center')
line(xs[1],568,xs[1],607,LINE,.8,[3,3]);line(xs[1],579,xs[1]+43,579,TEAL,1.05);line(xs[1]+43,579,xs[1]+43,603,TEAL,1.05);arrow(xs[1]+43,603,xs[1],603)
txt('Commit nach Policyprüfung',xs[1]+54,586,9,'Bold',TEAL)
caption(3,'Gezeigt ist der freigegebene Pfad. Bei Ablehnung folgt Korrektur. Das Urteil stammt vom Reviewer; Validierung und zulässiger Commit vom Orchestrator.',623)
y=body('Findings bleiben an Slice und meldenden Reviewer gebunden. Der Implementer beantwortet jeden offenen Befund begründet; nur der Reviewer kann ihn schließen. Ein Blocker ist durch den Implementer nicht zurückweisbar. Weitere abgelehnte Reviewrunden müssen Fortschritt belegen. [1]',664,size=10.2)
body('Das abschließende Review des vollständigen Branch-Diffs erzeugt bei neuen Findings einen gewöhnlichen Folgeauftrag. Ein abgeschlossener Lauf ist deshalb nicht automatisch befundfrei. Rundenlimits begrenzen erfolglose Schleifen; das Finalreview hat keine eigene Korrekturschleife. [1, 6, 7]',y,size=10.2)
end()

# 6. Providers
header(6,'Rollen und Provider','Austauschbar, mit Zulassung','Die Freigabe gilt je Provider und Slot. Herstellertrennung, gültige Nachweise und die laufgebundene Konfiguration bleiben verbindlich.')
y=table(['Provider','Implementer','Reviewer','Finalreviewer'],[['OpenAI Codex','Standard','Experimentell','Experimentell'],['Anthropic Claude Code','Experimentell','Standard','Standard'],['Google Antigravity','Nicht umgesetzt','Experimentell','Experimentell']],[159,116,116,116],235,41)
para('„Standard“ bezeichnet die ausgelieferten, intern als certified geführten Einträge. Experimental ist eine bewusste Zulassung mit dokumentierten Grenzen; keine externe Zertifizierung. Stand 01.10.2026. [2]',M,y+12,CW,9.4,12.5,MUTED,maxh=39)
y=sub('Zwei praktisch erprobte Besetzungen',y+70)
y=body('<b>Codex / Claude / Claude</b> bleibt die Standardbesetzung. <b>Claude / Codex / Codex</b> ist ausdrücklich per TOML wählbar und im vollständigen Workflow erprobt. Der Implementer-Hersteller muss sich von beiden Reviewer-Herstellern unterscheiden. Beide Review-Slots dürfen denselben Hersteller verwenden. [1, 2, 6]',y)
y=body('Die Zulassungstabelle ist kein Verzeichnis ausschließlich erlaubter Gesamtbesetzungen. Andere Mischungen zugelassener Slots können die Regeln erfüllen, benötigen aber einen eigenen Probelauf. Kandidaten starten nicht; ein Kontingentproblem löst keinen automatischen Anbieterwechsel aus. Modellwahl und Aliasnamen heben die Herstellertrennung nicht auf.',y)
y=sub('AGY als ergänzende Integration',y+2)
y=body('Antigravity dient hier der Vollständigkeit und dem Erproben zusätzlicher Providergrenzen. Der Schwerpunkt für Entwicklungsaufgaben liegt auf OpenAI und Anthropic. Beim Größenfall in Phase B lieferte AGY nur eines von 128 erwarteten Findings; 512 wurden nicht mehr gemessen. Die experimentelle Zulassung akzeptiert diese dokumentierte Schwäche, ist aber keine produktive Empfehlung oder Aussage gleicher Modellqualität. [4]',y,size=10.2)
callout('Was ein Profil bindet','Provider, Modell, Effort, Laufzeitgrenze und Binary-Identität; dazu Capability-, Transport-, Rechte-, Policy- und Zulassungsdigest. Isolation und Nachweisdateien werden beim Start und bei Resume erneut geprüft. [1, 2]',y+1,81)
end()

# 7. JSON portability
header(7,'Adapter und Verträge','Gleiches JSON ist nicht genug','Wie bei einer Datenbankabstraktion braucht ein gemeinsamer fachlicher Vertrag konkrete Übersetzungen an jeder Providergrenze.')
y=body('JSON normiert eine Syntax. Anbieter unterscheiden sich bei Schema-Teilmengen, Regex-Dialekten, Transporthüllen, Größenlimits, Werkzeugen und Berechtigungsregeln. Ein neutrales Rollenmodell löst diese Unterschiede nicht von selbst. Der Adapter übersetzt den fachlichen Vertrag in den jeweiligen Transport; die lokale Prüfung bleibt maßgeblich. [3]',231)
for x,t,d,col,bg in [(M,'Domainvertrag','Fachliche Bedeutung und<br/>Requestbindung',TEAL,PALE),(M+175,'Writer-Projektion','Providerkonformes Schema<br/>und gebundener Aufruf',BLUE,PB),(M+350,'Lokale Prüfung','Schema, Rolle, Identität<br/>und Workflowkontext',PURPLE,PP)]:box(x,353,157,75,t,d,col,bg)
arrow(M+159,390,M+170,390);arrow(M+334,390,M+345,390)
caption(4,'Die Projektion darf den fachlichen Vertrag nicht stillschweigend ersetzen. Abweichungen brauchen explizite lokale Gegenprüfungen.',449)
y=sub('Was erst der echte Aufruf zeigte',496)
y=body('Beim Codex-Reviewer scheiterte ein erzeugbares Schema zunächst an nicht geschlossenen Objektvarianten und anschließend an fehlenden Typangaben bei Literalen. Die Übersetzung musste diese Konstruktionen bedeutungserhaltend in den akzeptierten Writer überführen. Der AGY-Vorlauf hatte bereits Unterschiede bei Tupelschemas und erfolgreichen Prozessen ohne verwertbare strukturierte Antwort gezeigt. [3, 4]',y)
y=body('Auch Rechte sind ein Adaptervertrag: Eine falsche Settings-Struktur konnte in einer Claude-Probe Schutzkonfiguration still verwerfen. Gegenprüfungen mit der echten CLI, zusätzlicher Werkzeugbegrenzung und geprüften Schutzfeldern machten den Fehler sichtbar. Ein vereinfachter Fake hatte dafür nicht ausgereicht. [5, 8]',y)
callout('Die praktische Lehre','Ein bestandener Schema-, Adapter- oder direkter Kontrolltest ersetzt keinen vollständigen Orchestratorlauf. Erst der Produktivweg prüft zugleich Bootstrap, Records, Profilbindung, Prozessstart und Resume.',y+3,82)
end()

# 8. Records
header(8,'Persistenz und Bindungen','Records tragen die Autorität','Protokollmodus, Artefaktschema und Reducer sind getrennte Versionsebenen. Die autoritativen Fakten liegen in validierten Records.')
y=body('Der Protokollmodus heißt <font name="Mono">structured-v2</font>. Artefakt-Records verwenden <font name="Mono">orchestrator-artifact-v3</font> mit <font name="Mono">schema_version: "3"</font>; Implementer- und Reviewer-Nachrichten nutzen native v3-Verträge. Der gebundene Reducer bestimmt die Ableitung des Betriebszustands. [1, 3]',231)
cards=[('Eintrag P','record_id: P<br/>predecessor_ids: […]<br/>payload: …<br/>status: …','H(P)'),('Intent I','record_id: I<br/>predecessor_ids: [P]<br/>payload.phase: intent<br/>payload.effect_key: E','H(I)'),('Result R','record_id: R<br/>predecessor_ids: [I]<br/>payload.phase: result<br/>payload.effect_key: E','H(R)')]
for i,(title,detail,digest) in enumerate(cards):
 x=M+i*175
 rect(x,317,157,145,PALE,LINE,5)
 label(title.upper(),x+12,330)
 label('RECORD',x+12,349,MUTED,6.8)
 para(detail,x+12,362,133,8.1,12.3,font='Mono',maxh=51)
 line(x+12,420,x+145,420)
 label('UMSCHLAG',x+12,427,MUTED,6.8)
 txt('content_sha256: '+digest,x+12,441,8.1,'Mono')
arrow(M+159,390,M+170,390);arrow(M+334,390,M+345,390)
para('Paarbindung: Intent und Result beziehen sich auf denselben stabilen effect_key E.',M,477,CW,9.5,12.5,TEAL,maxh=26)
caption(5,'Vereinfachter Ausschnitt: Der Umschlag enthält record und content_sha256. Vorgänger-IDs binden die Folge; H bezeichnet SHA-256 des Recordinhalts.',503)
y=sub('Inhalt, Reihenfolge und Cache sind getrennt gebunden',539)
y=body('Der Repository-Fingerprint bindet die Prüfung an den Änderungsstand. Ein Record-Umschlag enthält den Inhaltsdigest; predecessor_ids referenzieren vorhandene Records. Der erste Vorgänger muss zum bisherigen Head passen. Intent und Result gehören über ihren stabilen Effektschlüssel zusammen. [1, 3]',y,size=10.2)
y=body('Der rekonstruierbare Head-Cache ergänzt eine fortgeschriebene chain_sha256 aus vorherigem Kettendigest und Record-ID. Das ist kein Vorgänger-Inhaltsdigest im Record. state.json, Checkpoints und head.json sind Ableitungen; fehlende autoritative Fakten dürfen nicht geraten werden.',y,size=10.2)
body('Hashes allein beweisen weder die Wahrheit eines Modellurteils noch verhindern sie ein vollständiges Neuschreiben aller Fakten und Referenzen. Geschwärzte öffentliche Exporte binden Original und Export über Herkunftsmanifeste; sie ersetzen keine originale Resume-Kette. [15]',y,size=10.2)
end()

# 9. Recovery
header(9,'Außenwirkungen und Recovery','Weiter nur bei klarem Zustand','Wiederaufnahme setzt eindeutige Fakten voraus. Ein unbekannter Ausgang darf weder als Erfolg noch als folgenloser Fehlversuch gelten.')
y=body('Git-Commit, Providerstart, autoritatives Schreiben und Queue-Bewegung werden durch stabile Intent-/Result-Paare erfasst. Bei offenem Intent darf Resume die betreffende Außenwirkung gezielt abgleichen: Ist sie nachweislich erfolgt, wird ihr Ergebnis nachvollzogen. Ist sie nachweislich nicht erfolgt, kann die erlaubte Wiederholung folgen. Ein unklarer Ausgang hält den Lauf an. [1]',231)
box(M+123,342,261,53,'Offener Intent beim Resume','Kanonische Records vollständig prüfen')
arrow(W/2,397,W/2,420);txt('Außenwirkung eindeutig feststellbar?',W/2,427,11,'Bold',TEAL,'center')
line(W/2,451,W/2,467);line(M+79,467,W-M-79,467)
for x,t,d,col,bg in [(M,'Erfolgt','Result abgleichen',TEAL,PALE),(M+175,'Nicht erfolgt','Erlaubt wiederholen',BLUE,PB),(M+350,'Unklar','Fail closed: Halt',AMBER,PA)]:
 arrow(x+78,467,x+78,488,col);box(x,495,157,60,t,d,col,bg)
caption(6,'Für jede Außenwirkung gelten eigene Abgleichregeln. Eine universelle Exactly-once-Garantie beliebiger Effekte ist damit nicht behauptet.',575)
y=body('SIGINT und SIGTERM müssen auch die gestarteten Providerprozesse kontrolliert beenden. Im realen Phase-C-Lauf wurden Implementierung und Review getrennt unterbrochen und fortgesetzt. Die gespeicherten Ergebnisse sowie die Prozesskontrolle belegen diese konkreten Pfade; sie decken nicht beliebige Infrastrukturfehler ab. [6]',619,size=10.2)
y=body('Resume bindet weiterhin Modell, Rechte und Evidenz. Ein veränderter relevanter Zustand kann ein ausdrücklich zu bestätigendes Gate verlangen. Änderungen der Zulassungsdigests können ältere Läufe nach einem Upgrade unfortsetzbar machen. Wiederaufnahme innerhalb eines Vertrags und Kompatibilität über Softwareupdates sind deshalb getrennte Eigenschaften. [1, 4, 5]',y,size=10.2)
end()

# 10. Qualification
header(10,'Qualifikation und Grenzen','Zulassung braucht mehrere Belege','Schutzproben, fachliche Bewertung und vollständiger Workflow beantworten unterschiedliche Fragen. Keine dieser Ebenen ersetzt die anderen.')
for x,t,d,col,bg in [(M,'1 · Schutz und Form','Offline-Gegenproben und\nechter Providertransport',BLUE,PB),(M+175,'2 · Fachliche Eignung','Verdeckte Sollbefunde und\nverblindete Bewertung',PURPLE,PP),(M+350,'3 · Gesamtweg','Slot-Canary und reale\nRollenbesetzung',TEAL,PALE)]:box(x,232,157,76,t,d.replace('\n','<br/>'),col,bg)
caption(7,'Ein Canary ist ein kleiner Kontrolllauf über den regulären Pfad. Er belegt keine breite Eignung für beliebige Entwicklungsaufgaben.',324)
y=table(['Prüfung','Gespeichertes Ergebnis'],[['Codex: Schutz / Format','P1–P6 und F1–F6 vollständig bestanden'],['Codex: Transport / Qualität','12/12; 4/4 Sollbefunde, davon 2 kritisch'],['Claude: Implementer-Paket','5/6; kein Ausschlussfehler; Regel erfüllt'],['Drei neue Slot-Canaries','Implementer und beide Review-Slots bestanden']],[208,299],371,34)
y=body('Auf beiden sauberen Fällen Q5 und Q6 erzeugte Codex keinen Fehlalarm; erfundene kritische Befunde gab es ebenfalls nicht. Die Claude-Referenz hatte auf Q6 einen unbegründeten Befund und erfüllte die Regel trotzdem. Der kleine Korpus ist keine Modellrangliste. [4]',y+14,size=10.1)
y=body('Im Claude-Paket blieb der Resume-Fall T5 formal negativ: Die fortgesetzte Implementierung bestand die verdeckten Tests, doch das anschließende Review lief in das Zeitlimit. Die vorab definierte Regel verlangt mindestens fünf von sechs Fällen ohne Ausschlussfehler wie Schutzpfadänderung, Testmanipulation oder Selbstfreigabe und war erfüllt. [5]',y,size=10.1)
y=body('Ausnahmen bleiben sichtbar: Bei 512 Findings stoppte Codex am Ausgabelimit, statt die vollständige Liste zu liefern; der 128er-Fall gelang nach zwei Timeouts und einer Vertragskorrektur. Bei Claude wurden W2 und W8 mit Befunden akzeptiert. W4 blieb wegen Providerverweigerung live ungemessen; eine Offline-Gegenprobe ersetzt diese Messung nicht. [4, 5]',y,size=10.1)
end()

# 11. Case study
header(11,'Fallstudie RuhestandsApp','Rollenwechsel im echten Lauf','Ein echter Entwicklungsauftrag prüft die neue Besetzung einschließlich Plan, Implementierung, Review, Korrektur und Wiederaufnahme.')
para('In einem isolierten Klon der RuhestandsApp ergänzt Claude als Implementer Regressionstests für die Ausgaben-Monatstabelle. Codex prüft Slice und Gesamtbranch. Der Lauf verwendet den unveränderten Orchestrator mit regulärer experimenteller Zulassung, ohne Kandidatenfreigabe. [6]',M,231,CW,10.2,13.6,maxh=55)
items=[('09:52–55','Plan freigegeben','Claude erstellt den Plan, Codex bestätigt den gebundenen Auftrag.'),('09:56','Implementierung unterbrochen','SIGINT beendet den Aufruf; fünf Sekunden später beginnt Resume.'),('09:59','Umsetzung und Tests','Testdatei fertig; npm test grün, zwei temporäre Mutationen erkannt.'),('10:30','Review manuell unterbrochen','Zeitlimit 0: Nach 31 Minuten ohne Ergebnis manuelles SIGINT und Resume.'),('10:32–36','Finding R-01 korrigiert','CSS-Prüfung nachgeschärft; Codex schließt den Slice-Befund.'),('10:38','Finalreview abgeschlossen','Zwei neue Findings erzeugen einen Folgeauftrag; der Lauf endet mit Exit 0.')]
line(M+78,323,M+78,552,LINE,1.1)
for i,(tm,t,d) in enumerate(items):
 yy=315+i*45;txt(tm,M,yy+2,8.5,'Mono',MUTED);dot(M+78,yy+7);txt(t,M+92,yy,10.5,'Bold');para(d,M+92,yy+17,CW-92,9.1,11.9,maxh=25)
para('1. Oktober 2026 · Europe/Berlin. Claude: Opus / high; Codex: gpt-6.1-sol / medium. Beide Unterbrechungen waren manuelle Eingriffe; es wurden keine Restprozesse beobachtet. Das Einrichtungsbeispiel nutzt heute 900 s für Codex-Reviews (S. 13). Exit 0 bedeutet hier keinen befundfreien Abschluss.',M,602,CW,9.8,13.2,MUTED,maxh=54)
y=body('Der Folgeauftrag hielt viermal an: dreimal im Umgang mit verweigerten Werkzeugaktionen, einmal wegen Providerüberlastung. Die Wiederaufnahmen und Korrekturen verteilen sich auf mehrere Orchestratorstände (Ablehnungsregel: S. 14). Am Ende blieben zwei neue Parserbefunde; der nächste Folgeauftrag ist nicht ausgeführt. [7]',665,size=10.1)
body('Die frühere Phase-A-Abnahme bleibt ein eigener Fall: Auto-Optimize erhielt in der RuhestandsApp einen separaten Tab; ein unterbrochener Wächter wurde erfolgreich fortgesetzt. [9]',y,size=10.1)
end()

# 12. Counts
header(12,'Umfang und Testnachweise','Zahlen mit benanntem Nenner','Codeumfang, Testmenge und experimentelle Eignung sind verschiedene Größen. Die Ausgabe trennt Messmethode, Versionsstand und Aussagekraft.')
for x,val,lab in [(M,'176.053','Python-Zeilen<br/>in src, tests, scripts'),(M+175,'1,51 : 1','Testzeilen / src-Zeilen'),(M+350,'4.870','Default-Suite: passed')]:
 rect(x,231,157,68,PALE,r=5);txt(val,x+12,243,24,'Light',TEAL);para(lab,x+12,274,133,8.3,10.2,MUTED,maxh=22)
y=table(['Verzeichnis','Dateien','Zeilen'],[['src','90','66.281'],['tests','143','99.811'],['scripts','39','9.961']],[277,100,130],320,34)
para('Gezählt werden versionierte reguläre *.py-Dateien aus einem Git-Archiv des Veröffentlichungsstands, einschließlich Leerzeilen, Kommentaren und Docstrings. Testquote: 99.811 / 66.281 = 1,51; einschließlich scripts im Nenner: 1,31. Dies ist keine Coverage-Messung. [8]',M,y+14,CW,9.5,12.6,MUTED,maxh=53)
y=sub('Testnachweise sind versionsgebunden',y+86)
y=body('Die Default-Suite des veröffentlichten Stands meldet <b>4.870 passed, 39 deselected</b>. Der zuletzt gesicherte vollständige Crash-Harness meldet <b>39 passed</b> auf einem früheren Stand; dessen Default-Suite meldete 4.822 passed. Die Crash-Zahl ist ausdrücklich kein erneuter Beleg auf dem letzten Veröffentlichungsstand. [8]',y,size=10.2)
y=body('Für dieses Papier wurden vorhandene Protokolle ausgewertet und mit Fundort, Digest und Versionszuordnung gesichert. Die Dokumenterstellung erzeugt weder eine neue Orchestrator-Attestierung noch eine nachträgliche Freigabe des aktuellen HEAD.',y,size=10.2)
y=body('Zum Vergleich: Phase A umfasste 150.729 Python-Zeilen bei einer Testquote von 1,41; nach Phase B waren es 160.096 Zeilen und 1,45. Der Zuwachs zeigt den erweiterten Prüf- und Integrationsumfang. Mehr Code oder Tests allein beweisen keine höhere Zuverlässigkeit. [8, 9]',y,size=10.2)
end()

# 13. Economics
header(13,'Betrieb mit begrenzten Kontingenten','Zeit kann Budget ersetzen','Der Orchestrator kann verfügbare Kapazität abwarten. Das eröffnet Betrieb mit kleinen Kontingenten, ohne daraus eine pauschale Kostenersparnis abzuleiten.')
y=body('Bei erkannten Quota-Problemen ist automatische Fortsetzung standardmäßig aktiv und konfigurierbar. Ein belastbarer Reset-Zeitpunkt oder die konfigurierte Wartezeit bestimmt den nächsten Versuch. Wartefenster und Wiederholungsgrenzen sind begrenzt; unbekannte Fehler dürfen nicht als beliebige Quota-Regel umgedeutet werden. Der gebundene Lauf bleibt erhalten. [1]',231)
for x,t,d,col,bg in [(M,'Arbeiten','Gebundener Provideraufruf',BLUE,PB),(M+175,'Warten','Reset / konfigurierte Pause',AMBER,PA),(M+350,'Fortsetzen','Profil und Zustand prüfen',TEAL,PALE)]:box(x,360,157,75,t,d,col,bg)
arrow(M+159,398,M+170,398);arrow(M+334,398,M+345,398)
caption(8,'Warten verändert die Durchlaufzeit. Es lockert weder Rollen-, Rechte- und Standbindung noch die Bedingungen für Review und Commit.',456)
y=body('Providerüberlastung ist ein anderer Fehlerfall als verbrauchtes Kontingent. Erkannte Überlastung wird begrenzt wiederholt, mit der konfigurierten maximalen Verzögerung zwischen Versuchen, standardmäßig 30 Sekunden. Zeitlimit 0 erklärt das manuell beendete stille Review auf S. 11. Das Einrichtungsbeispiel setzt heute 900 Sekunden für beide Codex-Reviewslots; dies ist eine Betriebsempfehlung, kein gemessenes Größenfall-Limit. [1, 8]',501,size=10.2)
y=body('Codex CLI unterstützt Anmeldung über ChatGPT oder API-Schlüssel; Claude Code kann über geeignete Abonnements oder API-Abrechnung betrieben werden. Der Orchestrator nutzt die konfigurierten CLIs. API-Abrechnung bedeutet hier keinen zusätzlichen direkten HTTP-Adapter im Orchestrator. Die verfügbaren Kontingente hängen vom Anbieter und gewählten Zugang ab. [10, 11]',y,size=10.2)
callout('Die praktische Wahl','Wer warten kann, kann kleinere Kontingente nutzen. Größere Kontingente oder API-Abrechnung ändern den Kapazitätsrahmen. Ein gemessener Euro-Vergleich liegt nicht vor; Token- und Cache-Zähler allein sind keine Rechnung.',y+3,87)
end()

# 14. Positioning
header(14,'Einordnung und offene Arbeit','Ein belastbarer, begrenzter Beitrag','Konkrete Verträge machen bekannte Architekturprinzipien im Betrieb prüfbar. Messgrenzen und Entscheidungen im Fehlerfall bleiben nachvollziehbar.')
y=body('<b>ESAA</b> verbindet strukturierte Agentenintentionen, deterministische Steuerung und ereignisbasierte Historie. <b>LangGraph</b> beschreibt Checkpoints und Wiederaufnahme; das <b>Evaluator-Optimizer</b>-Muster von Anthropic trennt Erzeugung und Bewertung. Diese Arbeiten sind Bezugspunkte; ein kontrollierter Leistungsvergleich liegt nicht vor. [12–14]',231,size=10.2)
y=body('Der Beitrag des Projekts liegt in der Verbindung von Git-Transaktionen, reviewergebundenen Findings, Validierung am Änderungsstand, Provideradaptern und rekonstruierbaren Außenwirkungen. Der reale Rollenwechsel prüfte ihr Zusammenspiel.',y,size=10.2)
y=sub('Ablehnungen klassifizieren, Grenzen getrennt sichern',y+2)
y=body('Eine verweigerte Werkzeugaktion stoppt den Lauf nicht pauschal. Erkennbare verbotene Aktionen und definierte Fehlerklassen stoppen weiterhin, etwa nicht lesende Git-Aufrufe, sichtbare Schreibversuche außerhalb von Repository und Scratch, geschützte Schreibzugriffe, Credential-Leseversuche, ungültige Eingaben oder indirekte Befehlsausführung. Bestimmte nicht auflösbare Schreibziele sind dagegen ausdrücklich toleriert. [5, 8]',y,size=10.2)
y=body('Das ist eine begrenzte Diagnoseentscheidung: Die Sandbox setzt die Schreibgrenze durch; der Schutzbaum-Fingerprint erkennt Änderungen geschützter Inhalte. Klassifikation erweitert keine Berechtigung. Unbekannte Ausgänge autoritativer Außenwirkungen bleiben fail-closed (S. 9). Regelkennung und privat gespeicherte Volleingabe erklären stoppende Ablehnungen, ohne sensible Eingaben im öffentlichen Bericht auszubreiten. [5, 8]',y,size=10.2)
y=sub('Was die Nachweise noch nicht tragen',y+2)
y=body('Codex wurde unter anderem mit high qualifiziert und im echten Lauf mit medium eingesetzt. Die Zulassung neuerer CLI-Versionen ist keine erneute Qualifikation aller Releases. Herstellertrennung bedeutet keine nachgewiesene statistische Unabhängigkeit. [2, 4, 6]',y,size=10.2)
y=body('Einer der zwei Blind-Rater gehörte zum Hersteller der Claude-Referenz. Diese dokumentierte Ausnahme begrenzt den Anbieter-Vergleich. Kleine Korpora erlauben weder eine allgemeine Modellrangliste noch einen Nachweis niedrigerer Gesamtkosten. [4]',y,size=10.2)
body('Offen bleiben breitere Entwicklungsaufgaben, längere Betriebsbeobachtung sowie einheitliche Härtung und verbleibende Settings-, Stop- und Werkzeuggrenzen. AGY bleibt ergänzend und experimentell im privaten WSL-2-Rahmen; der Reviewpfad sendet Snapshot und Evidenz an Google. [4, 5]',y,size=10.2)
end()

# 15. References
header(15,'Quellen und Reproduzierbarkeit','Belege statt bloßer Behauptungen','Repository-Quellen sind auf den dokumentierten Stand fixiert. Der Evidenzindex trennt Messstände, öffentliche Exporte und historische Nachweise.')
GH='https://github.com/dieteresser62-lab/Dual-Agent-Orchestrator/blob/c472d2196b347b4b40f428d32d21d593692f99a4/'
def ref(n,title,detail,url=None):
 global ry
 title=escape(title)
 if url:title=f'<link href="{escape(url)}" color="{TEAL}">{title}</link>'
 if 10<=n<=14:detail+=f'<br/><font size="8.1" color="{TEAL}">{escape(url.removeprefix("https://"))}</font>'
 ry=para(f'<b>[{n}] {title}</b><br/>{detail}',M,ry,CW,8.8,11.6,maxh=51)+6
ry=226
ref(1,'Orchestrated Agent Contract und Laufzeitkonfiguration','AGENTS.md; orchestrator.toml; src/agent_runtime.py; src/workflow_failure_recording.py; docs/reference/einrichtung.md.',GH+'AGENTS.md')
ref(2,'Rollen- und Providerzulassung','schemas/role-provider-certifications-v1.json; Status, Herstellertrennung und Profilbindung.',GH+'schemas/role-provider-certifications-v1.json')
ref(3,'Native Providerverträge und Adapter','src/native_provider_schema.py; src/artifact_models.py; src/artifact_store.py; zugehörige Schemas.',GH+'src/native_provider_schema.py')
ref(4,'Reviewer-Qualifikation: Codex und AGY','docs/reference/reviewer-certification.md; docs/reference/antigravity-reviewer.md; docs/evidence/codex/.',GH+'docs/reference/reviewer-certification.md')
ref(5,'Claude als Implementer','docs/reference/implementer-certification.md; src/permission_policy.py; docs/evidence/claude/.',GH+'docs/reference/implementer-certification.md')
ref(6,'Realer Rollenwechsel in der RuhestandsApp','docs/evidence/claude/topology-run-v1.json; zwei Unterbrechungen, Resume und Finalreview.',GH+'docs/evidence/claude/topology-run-v1.json')
ref(7,'Fortgesetzter Folgeauftrag','docs/evidence/claude/topology-followup-v1.json; mehrere Orchestratorstände, Befunde und Messgrenzen.',GH+'docs/evidence/claude/topology-followup-v1.json')
ref(8,'Begleitender Evidenzindex und Quellpaket','docs/reference/whitepaper-evidenz.md und docs/reference/whitepaper-quellen.zip; lokale Beilagen.','whitepaper-evidenz.md')
ref(9,'Architektur-Whitepaper Phase A, Ausgabe 1.3','28.09.2026; historische Abnahme, Umfangszahlen und eigener Evidenzindex.',GH+'docs/reference/architektur-whitepaper-phase-a.pdf')
ref(10,'OpenAI: Authentication','CLI-Zugänge über ChatGPT oder API-Schlüssel; Dokumentation abgerufen am 01.10.2026.','https://learn.chatgpt.com/docs/auth')
ref(11,'Anthropic: Use Claude Code with your Pro or Max plan','Abonnementzugang und Abrechnung; Dokumentation abgerufen am 01.10.2026.','https://support.claude.com/en/articles/11145838-use-claude-code-with-your-pro-or-max-plan')
ref(12,'ESAA: Event Sourcing for Autonomous Agents in LLM-Based Software Engineering','Elzo Brito Dos Santos Filho, 2026, arXiv:2602.23193.','https://arxiv.org/abs/2602.23193')
ref(13,'LangGraph: Persistence','Checkpoints und Wiederaufnahme; Dokumentation abgerufen am 01.10.2026.','https://docs.langchain.com/oss/python/langgraph/persistence')
ref(14,'Anthropic: Building effective agents','Abschnitt Evaluator-optimizer; abgerufen am 01.10.2026.','https://www.anthropic.com/engineering/building-effective-agents')
ref(15,'Herkunft der öffentlichen Evidenzexporte','docs/evidence/codex/redaction-manifest-v1.json; docs/evidence/claude/redaction-manifest-v1.json; docs/evidence/antigravity/redaction-manifest-v1.json.',GH+'docs/evidence/claude/redaction-manifest-v1.json')
end()
c.save()
reader=PdfReader(PDF)
assert len(reader.pages)==15
extracted='\n\n'.join(f'--- Seite {i+1} ---\n{p.extract_text()}' for i,p in enumerate(reader.pages))
(PDF.parent/'architektur-whitepaper.txt').write_text(extracted,encoding='utf-8')
(ROOT/'source'/'layout-boxes.json').write_text(json.dumps(BOXES,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'pdf':str(PDF),'pages':len(reader.pages),'bytes':PDF.stat().st_size},ensure_ascii=False))
