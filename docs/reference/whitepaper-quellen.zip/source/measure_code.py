"""Read-only Git-tree measurement; no checkout, provider or validation invocation.
Usage: python measure_code.py /path/to/Dual-Agent-Orchestrator [commit]
Counts physical lines including blanks, comments and docstrings in tracked *.py.
"""
import io
import json
import subprocess
import sys
import tarfile

repo = sys.argv[1]
ref = sys.argv[2] if len(sys.argv) > 2 else 'c472d2196b347b4b40f428d32d21d593692f99a4'
commit = subprocess.check_output(['git', '-C', repo, 'rev-parse', ref+'^{commit}'], text=True).strip()
data = subprocess.check_output(['git', '-C', repo, 'archive', commit])
counts = {root: {'files': 0, 'physical_lines': 0} for root in ('src', 'tests', 'scripts')}
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    for member in archive.getmembers():
        root = member.name.split('/')[0]
        if member.isfile() and root in counts and member.name.endswith('.py'):
            counts[root]['files'] += 1
            counts[root]['physical_lines'] += len(archive.extractfile(member).read().splitlines())
print(json.dumps({'commit': commit, 'counts': counts,
                  'test_to_src_ratio': counts['tests']['physical_lines']/counts['src']['physical_lines']}, indent=2))
