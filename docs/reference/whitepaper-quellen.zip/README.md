# Architektur-Whitepaper – Ausgabe 2.2

Vollständige Ausgabe zu den abgeschlossenen Phasen A–C, Stand 01.10.2026, 15 Seiten.

## Bearbeiten und erzeugen

Der gesamte gesetzte Text und die Vektorgrafiken stehen in `source/build_whitepaper.py`. `diagrams/*.puml` enthalten semantisch entsprechende UML- und Ablaufdiagramme für unabhängige Weiterbearbeitung. Sie werden nicht zusätzlich gerendert, um das PDF zu bauen.

Python 3.12 oder neuer, `reportlab==4.4.9` und `pypdf` installieren. Der Build verwendet Calibri, Segoe UI und Consolas als lokal vorhandene TTF-Dateien. Schriften sind nicht im Paket enthalten. Unter Windows wird `C:/Windows/Fonts`, unter WSL `/mnt/c/Windows/Fonts` automatisch verwendet.

```sh
python source/build_whitepaper.py
python source/build_whitepaper.py --font-dir /pfad/zu/ttf --output ausgabe.pdf
python source/measure_code.py /pfad/zum/repository c472d2196b347b4b40f428d32d21d593692f99a4
```

Erforderliche TTF-Dateien: `calibri.ttf`, `calibrib.ttf`, `calibrii.ttf`, `segoeuib.ttf`, `segoeuil.ttf`, `consola.ttf`.

Der Generator prüft seine Textflächen und schreibt PDF, Textauszug und Layoutkoordinaten. Canvas-Metadaten enthalten Erzeugungszeitpunkte; byteidentische Rebuilds werden nicht behauptet. Inhalt und Layout bleiben bei gleichen Bibliotheken und Schriften reproduzierbar. Für visuelle Prüfung mit Poppler: `pdftoppm -r 110 -png output/pdf/architektur-whitepaper.pdf seite`.

## Paketinhalt

- `output/pdf/`: fertiges PDF und extrahierter Lesetext.
- `source/`: vollständiger Generator, Zählverfahren, Zählergebnisse, Quellen- und Evidenzmetadaten.
- `diagrams/`: bearbeitbare Komponenten-, Sequenz-, Recovery-, Adapter- und Qualifikationsdiagramme.
- `whitepaper-evidence/`: unveränderte Testlogs, Versionsnotizen und ausgewählte bereits öffentliche Referenzdateien.
- `whitepaper-evidenz.md`: Aussagen, Fundstellen, Messgrenzen und Versionsbindungen.
- `SHA256SUMS.txt`: Prüfsummen aller ausgelieferten Dateien außer dieser Prüfsummendatei selbst.

Der Evidenzindex ist für seinen Ablageort im Repository `docs/reference/` geschrieben. Seine Links zur älteren Phase-A-Ausgabe und zu Nachbarartefakten lösen sich dort auf; diese ältere Ausgabe wird nicht dupliziert. Private Quelldaten, ursprüngliche Projektnamen der anonymisierten Vorgeschichte und persönliche Zugangsdaten gehören nicht zum Paket.

Die PDF-Beilage `whitepaper-evidenz.md` liegt zusätzlich neben dem PDF, damit dessen relative Quellenverknüpfung [8] lokal erreichbar ist.
